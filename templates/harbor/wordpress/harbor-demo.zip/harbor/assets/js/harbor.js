// Harbor: light/dark toggle. The visitor's choice is remembered; without a choice the
// site follows the device setting. When the owner locks a mode (Appearance → Harbor
// options), the toggle is hidden.
(function () {
  var root = document.documentElement;
  var toggles = document.querySelectorAll(".mode-toggle");
  if (!toggles.length) return;
  if (root.hasAttribute("data-mode-lock")) {
    toggles.forEach(function (t) { t.hidden = true; });
    return;
  }
  function currentMode() {
    var set = root.getAttribute("data-mode");
    if (set) return set;
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
  function label() {
    toggles.forEach(function (t) {
      t.setAttribute("aria-label", currentMode() === "dark" ? "Switch to light mode" : "Switch to dark mode");
    });
  }
  toggles.forEach(function (t) {
    t.addEventListener("click", function () {
      var next = currentMode() === "dark" ? "light" : "dark";
      root.setAttribute("data-mode", next);
      try { localStorage.setItem("harbor-mode", next); } catch (e) {}
      label();
    });
  });
  label();
})();
