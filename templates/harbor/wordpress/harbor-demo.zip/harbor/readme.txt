=== Harbor ===
Contributors: kandadigitalstudio
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 8.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A fast, accessible block theme for local service businesses, built to turn visitors into calls and quote requests.

== Description ==

Harbor is a block theme for plumbers, electricians, HVAC companies, cleaners, landscapers, roofers and every local service in between.

* Tap-to-call bar on phones, "Get a quote" on every page and an optional emergency banner
* Ready-made pages: services, service details, service areas and town pages, reviews, about, contact
* 30 patterns (ready-made sections and pages) under "Harbor sections" and "Harbor pages"
* Three styles (Clean, Bold, Warm), each with light and dark mode
* Light/dark follows each visitor's device, with a toggle; lock it under Appearance → Harbor options
* No page builder and no required plugins
* Styles the WPForms Lite and Contact Form 7 plugins to match

Full setup guide: see the docs included with your download.

== Installation ==

1. In WordPress, go to Appearance → Themes → Add New Theme → Upload Theme.
2. Choose the theme zip from the K&A download (the file whose name starts with "UPLOAD THIS") and click Install Now, then Activate.
3. Optional: import demo-content.xml (Tools → Import → WordPress) to get the demo pages.

== Frequently Asked Questions ==

= How do I change the main color? =

Appearance → Editor → Styles → Colors → Brand.

= How do I switch between Clean, Bold and Warm? =

Appearance → Editor → Styles, then pick a style.

= How do I keep the site always light or always dark? =

Appearance → Harbor options.

== Changelog ==

= 1.0.0 =
* First release.

== Copyright ==

Harbor WordPress Theme, Copyright 2026 K&A Digital Studio.
Harbor is distributed under the terms of the GNU GPL v2 or later.

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

Harbor bundles the following resources:

Icons: original icons by K&A Digital Studio, GPLv2 or later.
Placeholder images: created by K&A Digital Studio, GPLv2 or later.
