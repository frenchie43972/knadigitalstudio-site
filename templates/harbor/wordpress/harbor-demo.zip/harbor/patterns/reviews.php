<?php
/**
 * Title: Reviews
 * Slug: harbor/reviews
 * Categories: harbor
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:group {"className":"section-head is-center","layout":{"type":"default"}} -->
<div class="wp-block-group section-head is-center"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Reviews</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">What our neighbors say</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"18rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"card review","layout":{"type":"default"}} -->
<div class="wp-block-group card review"><!-- wp:html -->
<span class="stars" aria-hidden="true"><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"quote"} -->
<p class="quote">“Our water heater died on a Sunday. Harbor had a new one in by early evening, and the price was exactly what they quoted on the phone.”</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"reviewer","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reviewer"><!-- wp:html -->
<span class="avatar" aria-hidden="true">MR</span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>Maria R.</strong>Bayside · Water heater</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"card review","layout":{"type":"default"}} -->
<div class="wp-block-group card review"><!-- wp:html -->
<span class="stars" aria-hidden="true"><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"quote"} -->
<p class="quote">“Clear explanation, fair price, and they left the place cleaner than they found it. The electrician even labeled our whole panel.”</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"reviewer","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reviewer"><!-- wp:html -->
<span class="avatar" aria-hidden="true">DT</span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>David T.</strong>Cedar Hill · Electrical</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"card review","layout":{"type":"default"}} -->
<div class="wp-block-group card review"><!-- wp:html -->
<span class="stars" aria-hidden="true"><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"quote"} -->
<p class="quote">“We’ve used them for three years on the maintenance plan. Our furnace hasn’t missed a beat, and booking is always easy.”</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"reviewer","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reviewer"><!-- wp:html -->
<span class="avatar" aria-hidden="true">JA</span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>Jen &amp; Kofi A.</strong>Millbrook · Heating</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:paragraph {"className":"has-text-align-center","align":"center"} -->
<p class="has-text-align-center"><strong>4.9 out of 5</strong> from 212 reviews on Google · <a href="/reviews/">Read all reviews →</a></p>
<!-- /wp:paragraph --></section>
<!-- /wp:group -->
