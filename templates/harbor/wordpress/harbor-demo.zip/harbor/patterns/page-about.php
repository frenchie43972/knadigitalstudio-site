<?php
/**
 * Title: About page
 * Slug: harbor/page-about
 * Categories: harbor-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">About us</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">A local, family-owned team since 2008</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Harbor started with one van and one plumber. Today we’re a team of 14, and we still answer the phone ourselves.</p>
<!-- /wp:paragraph --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"harbor-photo"} -->
<figure class="wp-block-image size-large harbor-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/about.jpg' ) ); ?>" alt="A tool belt full of hand tools on a workbench"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:heading -->
<h2 class="wp-block-heading">Our story</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Mike Harbor opened the shop on Dock Street in 2008 with a simple idea: show up when you say you will, charge what you quoted, and leave the house cleaner than you found it.</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Neighbors noticed. Word spread from Bayside to the towns around the bay, and the team grew to include licensed electricians and heating &amp; cooling technicians, so one call covers the whole house.</p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"8rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"stat","layout":{"type":"default"}} -->
<div class="wp-block-group stat"><!-- wp:paragraph -->
<p><strong>18</strong>years local</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"stat","layout":{"type":"default"}} -->
<div class="wp-block-group stat"><!-- wp:paragraph -->
<p><strong>14</strong>team members</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"stat","layout":{"type":"default"}} -->
<div class="wp-block-group stat"><!-- wp:paragraph -->
<p><strong>9,400+</strong>jobs done</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"harbor/values"} /--><!-- wp:pattern {"slug":"harbor/team"} /--><!-- wp:pattern {"slug":"harbor/cta"} /-->
