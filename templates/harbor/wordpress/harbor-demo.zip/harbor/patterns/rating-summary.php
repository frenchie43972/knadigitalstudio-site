<?php
/**
 * Title: Rating summary
 * Slug: harbor/rating-summary
 * Categories: harbor
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center","width":"30%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:30%"><!-- wp:group {"className":"rating-big","layout":{"type":"default"}} -->
<div class="wp-block-group rating-big"><!-- wp:paragraph {"className":"big"} -->
<p class="big">4.9</p>
<!-- /wp:paragraph --><!-- wp:html -->
<span class="stars" aria-hidden="true"><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">212 Google reviews</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:table {"hasFixedLayout":false,"className":"price-list"} -->
<figure class="wp-block-table price-list"><table><thead><tr><th>Stars</th><th>Reviews</th></tr></thead><tbody><tr><td>5 stars</td><td>193</td></tr><tr><td>4 stars</td><td>14</td></tr><tr><td>3 stars</td><td>4</td></tr><tr><td>2 stars</td><td>0</td></tr><tr><td>1 star</td><td>1</td></tr></tbody></table></figure>
<!-- /wp:table --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
