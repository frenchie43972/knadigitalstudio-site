<?php
/**
 * Title: How it works
 * Slug: harbor/how-it-works
 * Categories: harbor
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:group {"className":"section-head is-center","layout":{"type":"default"}} -->
<div class="wp-block-group section-head is-center"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">How it works</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Fixed in three simple steps</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"15rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"step","layout":{"type":"default"}} -->
<div class="wp-block-group step"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">1</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Tell us what’s wrong</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Call or send a request. We’ll ask a few questions and book a time that suits you.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"step","layout":{"type":"default"}} -->
<div class="wp-block-group step"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">2</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Get a firm price</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>We diagnose the problem on site and agree the price with you before any work starts.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"step","layout":{"type":"default"}} -->
<div class="wp-block-group step"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">3</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Job done, guaranteed</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>We fix it, clean up, and back it with a one-year guarantee on parts and labor.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
