<?php
/**
 * Title: Privacy policy page
 * Slug: harbor/page-privacy
 * Categories: harbor-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Legal</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Privacy policy</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Last updated: [date]. This is a starting point. Have it reviewed for your business and location.</p>
<!-- /wp:paragraph --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading -->
<h2 class="wp-block-heading">What we collect</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>When you send a quote request or contact us, we collect your name, phone number, email address, town and the details you choose to share.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">How we use it</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Only to reply to you, schedule and carry out work, and send invoices. We don’t sell or rent your information.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Who we share it with</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Only with services that help us run the business, such as our form, scheduling and payment providers, and only as needed for those services.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">How long we keep it</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>As long as we need it for the work and our records, or as required by law.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Your choices</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>You can ask to see, correct or delete your information at any time by emailing <a href="mailto:hello@example.com">hello@example.com</a>.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
