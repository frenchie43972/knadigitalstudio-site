<?php
/**
 * Title: Quote form spot
 * Slug: harbor/quote-form-slot
 * Categories: harbor
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading -->
<h2 class="wp-block-heading">Send us the details</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">Add your quote form here. Install a free form plugin such as WPForms Lite or Contact Form 7, create a form, then replace this box with the form’s block or shortcode. Harbor styles both plugins to match.</p>
<!-- /wp:paragraph --><!-- wp:html -->
<div class="embed-slot"><svg class="icon" aria-hidden="true"><use href="#mail"></use></svg><strong>Your quote form goes here</strong><span>See “Quote form” in the Harbor guide.</span></div>
<!-- /wp:html --></div>
<!-- /wp:group -->
