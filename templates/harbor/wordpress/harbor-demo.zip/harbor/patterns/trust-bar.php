<?php
/**
 * Title: Trust bar
 * Slug: harbor/trust-bar
 * Categories: harbor
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"trust","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull trust"><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"14rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"trust-item","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group trust-item"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#shield"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph -->
<p>Licensed &amp; insured<span>State license #PL-20481</span></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"trust-item","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group trust-item"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#badge"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph -->
<p>18 years in business<span>Family owned since 2008</span></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"trust-item","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group trust-item"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#tag"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph -->
<p>Upfront pricing<span>No surprise fees, ever</span></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"trust-item","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group trust-item"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#check"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph -->
<p>1-year guarantee<span>On parts and labor</span></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
