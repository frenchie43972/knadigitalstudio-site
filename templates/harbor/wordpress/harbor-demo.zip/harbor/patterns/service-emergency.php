<?php
/**
 * Title: Service page: Emergency repairs
 * Slug: harbor/service-emergency
 * Categories: harbor-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Emergency repairs</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Burst pipe at 2 a.m.? We pick up and we come out</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">A real person answers day or night, every day of the year. We’ll tell you how to limit the damage while we’re on the way.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contact/">Get a free quote</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:+15035550142">(503) 555-0142</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"top"} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top","width":"64%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:64%"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"harbor-photo"} -->
<figure class="wp-block-image size-large harbor-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/emergency.jpg' ) ); ?>" alt="A plumber at work in a bathroom"/></figure>
<!-- /wp:image --><!-- wp:heading -->
<h2 class="wp-block-heading">What we do</h2>
<!-- /wp:heading --><!-- wp:list {"className":"checklist is-cols"} -->
<ul class="wp-block-list checklist is-cols">
<!-- wp:list-item -->
<li>Burst and leaking pipes</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>No heat or no cooling</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Sewer backups</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Electrical hazards and outages</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Water heater failures</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Gas smells (after calling your gas company)</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --><!-- wp:heading -->
<h2 class="wp-block-heading">Price guide</h2>
<!-- /wp:heading --><!-- wp:table {"hasFixedLayout":false,"className":"price-list"} -->
<figure class="wp-block-table price-list"><table><thead><tr><th>Job</th><th>Price</th></tr></thead><tbody><tr><td>Emergency call-out, any hour</td><td>$149</td></tr><tr><td>Extra charge for nights or weekends</td><td>none</td></tr><tr><td>Repairs</td><td>quoted before we start</td></tr></tbody></table></figure>
<!-- /wp:table --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">Every price is confirmed before work starts. No surprise fees.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Common questions</h2>
<!-- /wp:heading --><!-- wp:group {"className":"faq","layout":{"type":"default"}} -->
<div class="wp-block-group faq"><!-- wp:details -->
<details class="wp-block-details"><summary>Is it really 24/7?</summary><!-- wp:paragraph -->
<p>Yes. Calls go to someone on our team, including holidays.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>What should I do while I wait?</summary><!-- wp:paragraph -->
<p>We’ll talk you through it on the phone, for example how to shut off the water main.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:pattern {"slug":"harbor/quote-box"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"harbor/cta"} /-->
