<?php
/**
 * Title: Service page: Water heaters
 * Slug: harbor/service-water-heaters
 * Categories: harbor-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Water heaters</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Hot water back today, not next week</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Repairs and same-day replacement for tank and tankless water heaters, with old-unit removal included.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contact/">Get a free quote</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:+15035550142">(503) 555-0142</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"top"} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top","width":"64%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:64%"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"harbor-photo"} -->
<figure class="wp-block-image size-large harbor-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/water-heater.jpg' ) ); ?>" alt="A plumber tightening a valve next to a pressure gauge"/></figure>
<!-- /wp:image --><!-- wp:heading -->
<h2 class="wp-block-heading">What we do</h2>
<!-- /wp:heading --><!-- wp:list {"className":"checklist is-cols"} -->
<ul class="wp-block-list checklist is-cols">
<!-- wp:list-item -->
<li>Tank water heater repair</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Tankless water heater repair</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Same-day replacement</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Old unit removal</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Flushing and maintenance</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Expansion tanks</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --><!-- wp:heading -->
<h2 class="wp-block-heading">Price guide</h2>
<!-- /wp:heading --><!-- wp:table {"hasFixedLayout":false,"className":"price-list"} -->
<figure class="wp-block-table price-list"><table><thead><tr><th>Job</th><th>Price</th></tr></thead><tbody><tr><td>Repair visit and diagnosis</td><td>$149</td></tr><tr><td>Tank flush</td><td>$129</td></tr><tr><td>Tank water heater, installed</td><td>from $1,450</td></tr><tr><td>Tankless, installed</td><td>from $3,200</td></tr></tbody></table></figure>
<!-- /wp:table --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">Every price is confirmed before work starts. No surprise fees.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Common questions</h2>
<!-- /wp:heading --><!-- wp:group {"className":"faq","layout":{"type":"default"}} -->
<div class="wp-block-group faq"><!-- wp:details -->
<details class="wp-block-details"><summary>Can you replace it today?</summary><!-- wp:paragraph -->
<p>Usually, yes. We stock the most common sizes, so most replacements happen the same day.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Tank or tankless?</summary><!-- wp:paragraph -->
<p>We’ll go through the costs and savings of each so you can choose what suits your home.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:pattern {"slug":"harbor/quote-box"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"harbor/cta"} /-->
