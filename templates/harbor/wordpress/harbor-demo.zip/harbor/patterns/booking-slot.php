<?php
/**
 * Title: Booking calendar spot
 * Slug: harbor/booking-slot
 * Categories: harbor
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:group {"className":"section-head","layout":{"type":"default"}} -->
<div class="wp-block-group section-head"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Book online</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Pick a time that suits you</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Prefer to book yourself? Choose a slot below.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:html -->
<!-- Paste the embed code from your booking tool (Calendly, Square Appointments, Jobber, Housecall Pro) in place of this box. -->
<div class="embed-slot"><svg class="icon" aria-hidden="true"><use href="#calendar"></use></svg><strong>Your booking calendar goes here</strong><span>Replace this block with the embed code from your booking tool.</span></div>
<!-- /wp:html --></section>
<!-- /wp:group -->
