<?php
/**
 * Title: Contact details and hours
 * Slug: harbor/contact-details
 * Categories: harbor
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading -->
<h2 class="wp-block-heading">Call or visit</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"line-phone"} -->
<p class="line-phone"><strong>Phone, 24/7:</strong> <a href="tel:+15035550142">(503) 555-0142</a></p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"line-mail"} -->
<p class="line-mail"><strong>Email:</strong> <a href="mailto:hello@example.com">hello@example.com</a></p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"line-pin"} -->
<p class="line-pin"><strong>Shop:</strong> <a href="https://www.google.com/maps/search/?api=1&amp;query=120+Dock+Street+Bayside">120 Dock Street, Bayside</a></p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p><a href="https://www.google.com/maps/search/?api=1&amp;query=120+Dock+Street+Bayside"><strong>Get directions →</strong></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Opening hours</h3>
<!-- /wp:heading --><!-- wp:table {"hasFixedLayout":false,"className":"price-list"} -->
<figure class="wp-block-table price-list"><table><thead><tr><th>Day</th><th>Hours</th></tr></thead><tbody><tr><td>Monday – Friday</td><td>7 a.m. – 7 p.m.</td></tr><tr><td>Saturday</td><td>8 a.m. – 4 p.m.</td></tr><tr><td>Sunday</td><td>Emergencies only</td></tr></tbody></table></figure>
<!-- /wp:table --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
