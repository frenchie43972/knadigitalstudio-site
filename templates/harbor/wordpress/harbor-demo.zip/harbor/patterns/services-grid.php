<?php
/**
 * Title: Services grid
 * Slug: harbor/services-grid
 * Categories: harbor
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"section-head","layout":{"type":"default"}} -->
<div class="wp-block-group section-head"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Our services</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Everything your home needs, one call away</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">From a dripping tap to a new heating system, one team handles it, with the price agreed before we start.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"18rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#wrench"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Plumbing</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Leaks, clogs, fixtures and full repipes, done right the first time.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"price"} -->
<p class="price">From $89 <small>· service call</small></p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/services/plumbing/">See details →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#bolt"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Electrical</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Outlets, lighting, panel upgrades and EV chargers by licensed electricians.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"price"} -->
<p class="price">From $95 <small>· service call</small></p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/services/electrical/">See details →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#hvac"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Heating & cooling</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Furnace and AC repair, tune-ups and energy-efficient replacements.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"price"} -->
<p class="price">From $99 <small>· tune-up</small></p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/services/heating-cooling/">See details →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#drop"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Water heaters</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Repairs and same-day replacement for tank and tankless heaters.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"price"} -->
<p class="price">From $149 <small>· repair</small></p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/services/water-heaters/">See details →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#calendar"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Maintenance plans</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Yearly checkups for plumbing, electrical and HVAC, with priority booking.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"price"} -->
<p class="price">From $15 <small>· per month</small></p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/services/maintenance/">See details →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#clock"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Emergency repairs</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Burst pipe or no heat at 2 a.m.? We pick up and we come out.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"price"} -->
<p class="price">24/7 <small>· no extra fee to call</small></p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/services/emergency/">See details →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
