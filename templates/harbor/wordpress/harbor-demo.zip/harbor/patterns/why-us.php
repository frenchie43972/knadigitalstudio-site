<?php
/**
 * Title: Why choose us
 * Slug: harbor/why-us
 * Categories: harbor
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"harbor-photo"} -->
<figure class="wp-block-image size-large harbor-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/team.jpg' ) ); ?>" alt="A Harbor technician checking plans for a job"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Why Harbor</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">The kind of service you’d recommend to a neighbor</h2>
<!-- /wp:heading --><!-- wp:group {"className":"reasons","layout":{"type":"default"}} -->
<div class="wp-block-group reasons"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#clock"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">On time, or we call ahead</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>You get a two-hour arrival window and a text when we’re on the way.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#tag"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">The price we quote is the price you pay</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>We agree the price before any work starts. No surprises on the bill.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#house"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">We treat your home like ours</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Shoe covers on, drop cloths down, and we clean up before we leave.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"8rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"stat","layout":{"type":"default"}} -->
<div class="wp-block-group stat"><!-- wp:paragraph -->
<p><strong>18</strong>years local</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"stat","layout":{"type":"default"}} -->
<div class="wp-block-group stat"><!-- wp:paragraph -->
<p><strong>9,400+</strong>jobs done</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"stat","layout":{"type":"default"}} -->
<div class="wp-block-group stat"><!-- wp:paragraph -->
<p><strong>4.9★</strong>average rating</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
