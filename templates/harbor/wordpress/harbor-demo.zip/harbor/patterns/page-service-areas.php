<?php
/**
 * Title: Service areas page
 * Slug: harbor/page-service-areas
 * Categories: harbor-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Service area</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Proudly serving Bayside and 12 nearby towns</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Local crews mean faster arrival times. Don’t see your town? Call us; we may still be able to help.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contact/">Get a free quote</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:+15035550142">(503) 555-0142</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"section-head","layout":{"type":"default"}} -->
<div class="wp-block-group section-head"><!-- wp:heading -->
<h2 class="wp-block-heading">Towns we serve</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"16rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"town","layout":{"type":"default"},"anchor":"bayside"} -->
<div id="bayside" class="wp-block-group town"><!-- wp:heading {"level":3,"className":"has-pin"} -->
<h3 class="wp-block-heading has-pin">Bayside</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Our home base. Fastest arrival times, often within the hour.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/service-areas/bayside/">Plumbers &amp; electricians in Bayside →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"town","layout":{"type":"default"},"anchor":"northgate"} -->
<div id="northgate" class="wp-block-group town"><!-- wp:heading {"level":3,"className":"has-pin"} -->
<h3 class="wp-block-heading has-pin">Northgate</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Daily crews in Northgate, including weekends.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="tel:+15035550142">Call to book in Northgate →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"town","layout":{"type":"default"},"anchor":"cedar-hill"} -->
<div id="cedar-hill" class="wp-block-group town"><!-- wp:heading {"level":3,"className":"has-pin"} -->
<h3 class="wp-block-heading has-pin">Cedar Hill</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Same-day visits for most calls in Cedar Hill.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="tel:+15035550142">Call to book in Cedar Hill →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"town","layout":{"type":"default"},"anchor":"millbrook"} -->
<div id="millbrook" class="wp-block-group town"><!-- wp:heading {"level":3,"className":"has-pin"} -->
<h3 class="wp-block-heading has-pin">Millbrook</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Serving Millbrook homes and small businesses.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="tel:+15035550142">Call to book in Millbrook →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"town","layout":{"type":"default"},"anchor":"lakeview"} -->
<div id="lakeview" class="wp-block-group town"><!-- wp:heading {"level":3,"className":"has-pin"} -->
<h3 class="wp-block-heading has-pin">Lakeview</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Same-day service across Lakeview.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="tel:+15035550142">Call to book in Lakeview →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"town","layout":{"type":"default"},"anchor":"westport"} -->
<div id="westport" class="wp-block-group town"><!-- wp:heading {"level":3,"className":"has-pin"} -->
<h3 class="wp-block-heading has-pin">Westport</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Daily routes through Westport.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="tel:+15035550142">Call to book in Westport →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"town","layout":{"type":"default"},"anchor":"fairhaven"} -->
<div id="fairhaven" class="wp-block-group town"><!-- wp:heading {"level":3,"className":"has-pin"} -->
<h3 class="wp-block-heading has-pin">Fairhaven</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Same-day visits for most calls in Fairhaven.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="tel:+15035550142">Call to book in Fairhaven →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"town","layout":{"type":"default"},"anchor":"oak-ridge"} -->
<div id="oak-ridge" class="wp-block-group town"><!-- wp:heading {"level":3,"className":"has-pin"} -->
<h3 class="wp-block-heading has-pin">Oak Ridge</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Regular weekday routes through Oak Ridge.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="tel:+15035550142">Call to book in Oak Ridge →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"town","layout":{"type":"default"},"anchor":"pine-grove"} -->
<div id="pine-grove" class="wp-block-group town"><!-- wp:heading {"level":3,"className":"has-pin"} -->
<h3 class="wp-block-heading has-pin">Pine Grove</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Weekday service in Pine Grove.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="tel:+15035550142">Call to book in Pine Grove →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"town","layout":{"type":"default"},"anchor":"riverside"} -->
<div id="riverside" class="wp-block-group town"><!-- wp:heading {"level":3,"className":"has-pin"} -->
<h3 class="wp-block-heading has-pin">Riverside</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Serving Riverside and the river road.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="tel:+15035550142">Call to book in Riverside →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"town","layout":{"type":"default"},"anchor":"south-bay"} -->
<div id="south-bay" class="wp-block-group town"><!-- wp:heading {"level":3,"className":"has-pin"} -->
<h3 class="wp-block-heading has-pin">South Bay</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Same-day visits across South Bay.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="tel:+15035550142">Call to book in South Bay →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"town","layout":{"type":"default"},"anchor":"elm-park"} -->
<div id="elm-park" class="wp-block-group town"><!-- wp:heading {"level":3,"className":"has-pin"} -->
<h3 class="wp-block-heading has-pin">Elm Park</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Weekday service in Elm Park.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="tel:+15035550142">Call to book in Elm Park →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"town","layout":{"type":"default"},"anchor":"harbor-point"} -->
<div id="harbor-point" class="wp-block-group town"><!-- wp:heading {"level":3,"className":"has-pin"} -->
<h3 class="wp-block-heading has-pin">Harbor Point</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Serving the Point and the marina area.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="tel:+15035550142">Call to book in Harbor Point →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"harbor/cta"} /-->
