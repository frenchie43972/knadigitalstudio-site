<?php
/**
 * Title: Services page
 * Slug: harbor/page-services
 * Categories: harbor-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Our services</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">One call for plumbing, electrical and heating &amp; cooling</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Licensed pros for every part of your home, with the price agreed before we start.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contact/">Get a free quote</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:+15035550142">(503) 555-0142</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"harbor/services-grid"} /--><!-- wp:pattern {"slug":"harbor/how-it-works"} /--><!-- wp:pattern {"slug":"harbor/cta"} /-->
