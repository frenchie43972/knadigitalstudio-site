<?php
/**
 * Title: Reviews page
 * Slug: harbor/page-reviews
 * Categories: harbor-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Reviews</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Rated 4.9 by our neighbors</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">We earn our reviews one job at a time. Here’s what homeowners across the bay say.</p>
<!-- /wp:paragraph --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:pattern {"slug":"harbor/rating-summary"} /--><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"18rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"card review","layout":{"type":"default"}} -->
<div class="wp-block-group card review"><!-- wp:html -->
<span class="stars" aria-hidden="true"><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"quote"} -->
<p class="quote">“Our water heater died on a Sunday. Harbor had a new one in by early evening, and the price was exactly what they quoted on the phone.”</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"reviewer","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reviewer"><!-- wp:html -->
<span class="avatar" aria-hidden="true">MR</span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>Maria R.</strong>Bayside · Water heater</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"card review","layout":{"type":"default"}} -->
<div class="wp-block-group card review"><!-- wp:html -->
<span class="stars" aria-hidden="true"><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"quote"} -->
<p class="quote">“Clear explanation, fair price, and they left the place cleaner than they found it. The electrician even labeled our whole panel.”</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"reviewer","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reviewer"><!-- wp:html -->
<span class="avatar" aria-hidden="true">DT</span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>David T.</strong>Cedar Hill · Electrical</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"card review","layout":{"type":"default"}} -->
<div class="wp-block-group card review"><!-- wp:html -->
<span class="stars" aria-hidden="true"><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"quote"} -->
<p class="quote">“We’ve used them for three years on the maintenance plan. Our furnace hasn’t missed a beat, and booking is always easy.”</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"reviewer","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reviewer"><!-- wp:html -->
<span class="avatar" aria-hidden="true">JA</span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>Jen &amp; Kofi A.</strong>Millbrook · Heating</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"card review","layout":{"type":"default"}} -->
<div class="wp-block-group card review"><!-- wp:html -->
<span class="stars" aria-hidden="true"><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"quote"} -->
<p class="quote">“Called at 7 a.m. about a leak under the sink and they were here by 9. Friendly, fast and no mess.”</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"reviewer","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reviewer"><!-- wp:html -->
<span class="avatar" aria-hidden="true">SL</span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>Sam L.</strong>Northgate · Plumbing</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"card review","layout":{"type":"default"}} -->
<div class="wp-block-group card review"><!-- wp:html -->
<span class="stars" aria-hidden="true"><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"quote"} -->
<p class="quote">“Our AC quit in a heat wave. They got us a same-day visit and had it running again before dinner.”</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"reviewer","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reviewer"><!-- wp:html -->
<span class="avatar" aria-hidden="true">PN</span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>Priya N.</strong>Lakeview · Cooling</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"card review","layout":{"type":"default"}} -->
<div class="wp-block-group card review"><!-- wp:html -->
<span class="stars" aria-hidden="true"><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"quote"} -->
<p class="quote">“Pipe burst at midnight. Someone actually answered, talked me through shutting off the water, and was here in 40 minutes.”</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"reviewer","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reviewer"><!-- wp:html -->
<span class="avatar" aria-hidden="true">RG</span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>Rosa G.</strong>Westport · Emergency</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"card review","layout":{"type":"default"}} -->
<div class="wp-block-group card review"><!-- wp:html -->
<span class="stars" aria-hidden="true"><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"quote"} -->
<p class="quote">“Installed our EV charger and handled the permit. Professional from quote to inspection.”</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"reviewer","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reviewer"><!-- wp:html -->
<span class="avatar" aria-hidden="true">TB</span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>Tom B.</strong>Fairhaven · Electrical</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"card review","layout":{"type":"default"}} -->
<div class="wp-block-group card review"><!-- wp:html -->
<span class="stars" aria-hidden="true"><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"quote"} -->
<p class="quote">“Honest advice: they told us a repair would do instead of selling us a new fixture. That earned our trust.”</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"reviewer","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reviewer"><!-- wp:html -->
<span class="avatar" aria-hidden="true">AK</span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>Anita K.</strong>Oak Ridge · Plumbing</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"card review","layout":{"type":"default"}} -->
<div class="wp-block-group card review"><!-- wp:html -->
<span class="stars" aria-hidden="true"><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"quote"} -->
<p class="quote">“The yearly checkup caught a failing valve before it flooded our basement. The plan has paid for itself.”</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"reviewer","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reviewer"><!-- wp:html -->
<span class="avatar" aria-hidden="true">CW</span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>Chris W.</strong>Bayside · Maintenance plan</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:buttons {"className":"is-content-justification-center"} -->
<div class="wp-block-buttons is-content-justification-center">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="https://www.google.com/maps">Leave us a Google review</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"harbor/cta"} /-->
