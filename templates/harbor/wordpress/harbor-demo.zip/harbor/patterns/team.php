<?php
/**
 * Title: Team and licenses
 * Slug: harbor/team
 * Categories: harbor
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"section-head is-center","layout":{"type":"default"}} -->
<div class="wp-block-group section-head is-center"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">The team</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">The people you’ll meet</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"13rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">MH</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Mike Harbor</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Founder · Master plumber</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">LH</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Lena Harbor</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Operations · Scheduling</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">DO</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Dev Okafor</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Lead electrician</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">RS</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Rachel Soto</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>HVAC technician</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:heading {"level":3,"className":"has-text-align-center"} -->
<h3 class="wp-block-heading has-text-align-center">Licenses and memberships</h3>
<!-- /wp:heading --><!-- wp:list {"className":"checklist is-cols"} -->
<ul class="wp-block-list checklist is-cols">
<!-- wp:list-item -->
<li>State plumbing license #PL-20481</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>State electrical license #EL-77310</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>EPA 608 certified HVAC technicians</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Fully insured, $2M liability</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></section>
<!-- /wp:group -->
