<?php
/**
 * Title: Service page: Heating & cooling
 * Slug: harbor/service-heating-cooling
 * Categories: harbor-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Heating & cooling</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Stay comfortable all year, whatever the weather</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Furnace repair, AC tune-ups and energy-efficient replacements, with honest advice about repair versus replace.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contact/">Get a free quote</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:+15035550142">(503) 555-0142</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"top"} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top","width":"64%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:64%"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"harbor-photo"} -->
<figure class="wp-block-image size-large harbor-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/hvac.jpg' ) ); ?>" alt="An outdoor air conditioning unit beside a house"/></figure>
<!-- /wp:image --><!-- wp:heading -->
<h2 class="wp-block-heading">What we do</h2>
<!-- /wp:heading --><!-- wp:list {"className":"checklist is-cols"} -->
<ul class="wp-block-list checklist is-cols">
<!-- wp:list-item -->
<li>Furnace and boiler repair</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Air conditioner repair</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Seasonal tune-ups</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Heat pumps</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Thermostats</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>System replacement</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --><!-- wp:heading -->
<h2 class="wp-block-heading">Price guide</h2>
<!-- /wp:heading --><!-- wp:table {"hasFixedLayout":false,"className":"price-list"} -->
<figure class="wp-block-table price-list"><table><thead><tr><th>Job</th><th>Price</th></tr></thead><tbody><tr><td>Tune-up (heating or cooling)</td><td>$99</td></tr><tr><td>Repair visit and diagnosis</td><td>$99</td></tr><tr><td>Smart thermostat install</td><td>from $189</td></tr><tr><td>New system estimate</td><td>free</td></tr></tbody></table></figure>
<!-- /wp:table --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">Every price is confirmed before work starts. No surprise fees.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Common questions</h2>
<!-- /wp:heading --><!-- wp:group {"className":"faq","layout":{"type":"default"}} -->
<div class="wp-block-group faq"><!-- wp:details -->
<details class="wp-block-details"><summary>Repair or replace?</summary><!-- wp:paragraph -->
<p>If a repair makes more sense, we’ll say so. We only suggest replacing when the numbers add up for you.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>How often should I get a tune-up?</summary><!-- wp:paragraph -->
<p>Once a year for heating and once for cooling keeps systems efficient and catches problems early.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:pattern {"slug":"harbor/quote-box"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"harbor/cta"} /-->
