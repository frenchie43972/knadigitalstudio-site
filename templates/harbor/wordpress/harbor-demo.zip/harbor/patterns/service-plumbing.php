<?php
/**
 * Title: Service page: Plumbing
 * Slug: harbor/service-plumbing
 * Categories: harbor-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Plumbing</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Leaks, clogs and fixtures, fixed right the first time</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">From a dripping tap to a full repipe, our licensed plumbers arrive with the parts to finish most jobs in one visit.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contact/">Get a free quote</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:+15035550142">(503) 555-0142</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"top"} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top","width":"64%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:64%"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"harbor-photo"} -->
<figure class="wp-block-image size-large harbor-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/plumbing.jpg' ) ); ?>" alt="A plumber fixing pipes under a bathroom sink"/></figure>
<!-- /wp:image --><!-- wp:heading -->
<h2 class="wp-block-heading">What we do</h2>
<!-- /wp:heading --><!-- wp:list {"className":"checklist is-cols"} -->
<ul class="wp-block-list checklist is-cols">
<!-- wp:list-item -->
<li>Leak detection and repair</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Clogged drains and toilets</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Faucets, sinks and fixtures</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Garbage disposals</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Sump pumps</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Repiping and pipe repair</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --><!-- wp:heading -->
<h2 class="wp-block-heading">Price guide</h2>
<!-- /wp:heading --><!-- wp:table {"hasFixedLayout":false,"className":"price-list"} -->
<figure class="wp-block-table price-list"><table><thead><tr><th>Job</th><th>Price</th></tr></thead><tbody><tr><td>Service call and diagnosis</td><td>$89</td></tr><tr><td>Faucet or fixture replacement</td><td>from $149</td></tr><tr><td>Toilet repair</td><td>from $129</td></tr><tr><td>Drain cleaning</td><td>from $79</td></tr></tbody></table></figure>
<!-- /wp:table --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">Every price is confirmed before work starts. No surprise fees.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Common questions</h2>
<!-- /wp:heading --><!-- wp:group {"className":"faq","layout":{"type":"default"}} -->
<div class="wp-block-group faq"><!-- wp:details -->
<details class="wp-block-details"><summary>How quickly can you come out?</summary><!-- wp:paragraph -->
<p>Most calls get a same-day visit. Emergencies are answered 24/7.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Do you bring parts with you?</summary><!-- wp:paragraph -->
<p>Our vans carry the common parts, so most repairs are finished on the first visit.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:pattern {"slug":"harbor/quote-box"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"harbor/cta"} /-->
