<?php
/**
 * Title: Hero with photo and call buttons
 * Slug: harbor/hero
 * Categories: harbor
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section hero"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center","width":"52%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:52%"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Plumbing · Electrical · Heating &amp; cooling</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Fast, friendly home repairs. Same&#8209;day service.</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Licensed local pros, upfront prices and a one-year guarantee on every job. Serving Bayside and 12 nearby towns.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contact/">Get a free quote</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:+15035550142">(503) 555-0142</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --><!-- wp:list {"className":"hero-points"} -->
<ul class="wp-block-list hero-points">
<!-- wp:list-item -->
<li>Upfront pricing</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Licensed &amp; insured</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>1-year guarantee</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --><!-- wp:paragraph {"className":"hero-rating"} -->
<p class="hero-rating"><a href="/reviews/"><strong>4.9</strong> from 212 Google reviews</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"harbor-photo is-hero"} -->
<figure class="wp-block-image size-large harbor-photo is-hero"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/hero.jpg' ) ); ?>" alt="A smiling Harbor plumber fixing pipes under a sink"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
