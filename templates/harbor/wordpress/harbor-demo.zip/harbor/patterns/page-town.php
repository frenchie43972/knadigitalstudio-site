<?php
/**
 * Title: Town page (example: Bayside)
 * Slug: harbor/page-town
 * Categories: harbor-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Bayside</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Plumbers, electricians and HVAC pros in Bayside</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Bayside is our home base. Most calls here get a visit the same day, often within the hour.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contact/">Get a free quote</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:+15035550142">(503) 555-0142</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"top"} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top","width":"64%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:64%"><!-- wp:heading -->
<h2 class="wp-block-heading">Local, licensed and close by</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>We’ve worked on Bayside homes since 2008, from the older houses near the harbor to the new builds up the hill. We know the area’s pipes, panels and systems, and our shop on Dock Street means we’re rarely more than a few minutes away.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Services in Bayside</h2>
<!-- /wp:heading --><!-- wp:list {"className":"checklist is-cols"} -->
<ul class="wp-block-list checklist is-cols">
<!-- wp:list-item -->
<li><a href="/services/plumbing/">Plumbing</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="/services/electrical/">Electrical</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="/services/heating-cooling/">Heating & cooling</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="/services/water-heaters/">Water heaters</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="/services/maintenance/">Maintenance plans</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="/services/emergency/">Emergency repairs</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --><!-- wp:heading -->
<h2 class="wp-block-heading">What Bayside neighbors say</h2>
<!-- /wp:heading --><!-- wp:group {"className":"card review","layout":{"type":"default"}} -->
<div class="wp-block-group card review"><!-- wp:html -->
<span class="stars" aria-hidden="true"><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg><svg class="icon"><use href="#star"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"quote"} -->
<p class="quote">“Our water heater died on a Sunday. Harbor had a new one in by early evening, and the price was exactly what they quoted on the phone.”</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"reviewer","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reviewer"><!-- wp:html -->
<span class="avatar" aria-hidden="true">MR</span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>Maria R.</strong>Bayside · Water heater</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">This is an example town page. Duplicate it for each town you want to show up for in search, then change the name, details and review.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:pattern {"slug":"harbor/quote-box"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"harbor/cta"} /-->
