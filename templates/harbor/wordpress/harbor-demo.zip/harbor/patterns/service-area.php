<?php
/**
 * Title: Service area with map
 * Slug: harbor/service-area
 * Categories: harbor
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"area","layout":{"type":"default"}} -->
<div class="wp-block-group area"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Service area</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Proudly serving Bayside and nearby</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Local crews mean faster arrival times. Not sure if we cover you? Just call.</p>
<!-- /wp:paragraph --><!-- wp:list {"className":"towns"} -->
<ul class="wp-block-list towns">
<!-- wp:list-item -->
<li><a href="/service-areas/bayside/">Bayside</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="/service-areas/#northgate">Northgate</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="/service-areas/#cedar-hill">Cedar Hill</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="/service-areas/#millbrook">Millbrook</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="/service-areas/#lakeview">Lakeview</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="/service-areas/#westport">Westport</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="/service-areas/#fairhaven">Fairhaven</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="/service-areas/">+ 6 more</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/service-areas/">See all service areas</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:html -->
<div class="map" role="img" aria-label="Map of the Bayside service area"><svg viewBox="0 0 440 300" aria-hidden="true"><rect width="440" height="300" fill="var(--bg-soft)"/><path d="M0 0h120c-20 40 10 70-10 110s30 80 10 120-20 50-20 70H0z" fill="color-mix(in srgb, var(--brand) 16%, var(--bg-soft))"/><g fill="none" stroke="var(--border)" stroke-width="10" stroke-linecap="round"><path d="M120 60h300M110 150h320M120 240h300M200 0v300M310 0v300"/></g><g fill="none" stroke="color-mix(in srgb, var(--text-soft) 35%, transparent)" stroke-width="2" stroke-dasharray="2 8"><path d="M150 20c90 40 160 20 270 70M140 280c100-40 180-10 290-60"/></g><circle cx="255" cy="150" r="78" fill="color-mix(in srgb, var(--brand) 12%, transparent)" stroke="var(--brand-text)" stroke-width="2" stroke-dasharray="6 6"/><g fill="var(--brand-text)"><path d="M255 132c-11 0-19 8-19 18 0 14 19 30 19 30s19-16 19-30c0-10-8-18-19-18z"/><circle cx="185" cy="95" r="6"/><circle cx="330" cy="105" r="6"/><circle cx="300" cy="205" r="6"/><circle cx="200" cy="210" r="6"/><circle cx="355" cy="170" r="6"/></g><circle cx="255" cy="150" r="6" fill="var(--surface)"/><text x="40" y="160" fill="var(--brand-text)" font-family="system-ui, sans-serif" font-size="13" font-weight="700" letter-spacing="2">HARBOR</text></svg></div>
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
