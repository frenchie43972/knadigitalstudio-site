<?php
/**
 * Title: Questions and answers
 * Slug: harbor/faq
 * Categories: harbor
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"section-head is-center","layout":{"type":"default"}} -->
<div class="wp-block-group section-head is-center"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Questions</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Good to know before you call</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"className":"faq","layout":{"type":"default"}} -->
<div class="wp-block-group faq"><!-- wp:details -->
<details class="wp-block-details"><summary>Do you charge for estimates?</summary><!-- wp:paragraph -->
<p>No. Estimates are free. For repairs we charge a flat service-call fee, which goes toward the job if you go ahead.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Are your technicians licensed and insured?</summary><!-- wp:paragraph -->
<p>Yes. Every plumber and electrician is state licensed, and we carry full liability insurance. We’re happy to show proof.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Do you really answer at night and on weekends?</summary><!-- wp:paragraph -->
<p>Yes. Emergency calls go to a person on our team, 24 hours a day, 7 days a week, including holidays.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>How do I pay?</summary><!-- wp:paragraph -->
<p>Card, check or bank transfer when the job is done. Financing is available for larger projects.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
