<?php
/**
 * Title: Service page: Maintenance plans
 * Slug: harbor/service-maintenance
 * Categories: harbor-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Maintenance plans</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Catch small problems before they become big bills</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">One yearly plan covers plumbing, electrical and HVAC checkups, with priority booking and member discounts.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contact/">Get a free quote</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:+15035550142">(503) 555-0142</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"top"} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top","width":"64%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:64%"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"harbor-photo"} -->
<figure class="wp-block-image size-large harbor-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/maintenance.jpg' ) ); ?>" alt="Setting a smart thermostat on the wall"/></figure>
<!-- /wp:image --><!-- wp:heading -->
<h2 class="wp-block-heading">What we do</h2>
<!-- /wp:heading --><!-- wp:list {"className":"checklist is-cols"} -->
<ul class="wp-block-list checklist is-cols">
<!-- wp:list-item -->
<li>Yearly heating and cooling tune-ups</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Plumbing inspection</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Electrical safety check</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Priority scheduling</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>15% off repairs</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>No overtime charges</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --><!-- wp:heading -->
<h2 class="wp-block-heading">Price guide</h2>
<!-- /wp:heading --><!-- wp:table {"hasFixedLayout":false,"className":"price-list"} -->
<figure class="wp-block-table price-list"><table><thead><tr><th>Job</th><th>Price</th></tr></thead><tbody><tr><td>Home plan</td><td>$15 / month</td></tr><tr><td>Home Plus plan (two systems)</td><td>$25 / month</td></tr><tr><td>Cancel anytime</td><td>no fee</td></tr></tbody></table></figure>
<!-- /wp:table --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">Every price is confirmed before work starts. No surprise fees.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Common questions</h2>
<!-- /wp:heading --><!-- wp:group {"className":"faq","layout":{"type":"default"}} -->
<div class="wp-block-group faq"><!-- wp:details -->
<details class="wp-block-details"><summary>What does a checkup include?</summary><!-- wp:paragraph -->
<p>A full inspection, cleaning where needed, and a written report on anything that needs attention.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Can I cancel?</summary><!-- wp:paragraph -->
<p>Yes, anytime, with no cancellation fee.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:pattern {"slug":"harbor/quote-box"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"harbor/cta"} /-->
