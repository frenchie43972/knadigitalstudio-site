=== Lantern ===
Contributors: kandadigitalstudio
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 8.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A fast, accessible block theme for any kind of small nonprofit, built to bring in donations and volunteers and help people find help.

== Description ==

Lantern is a block theme for every kind of small nonprofit: shelters, youth programs, food banks, animal rescues, senior services, arts groups, community groups and everything in between. The demo is a food pantry; every page works for any cause.

* Donate button on every page and in the phone bar, "your gift at work" amounts and a campaign goal meter
* A "Get help" page for the people you serve: who can come, what to bring, hours and places
* Ready-made pages: programs, program details, donate, volunteer, events, our impact, about, contact
* Impact numbers, "where the money goes" and an annual report download, for donors and funders
* 36 patterns (ready-made sections and pages) under "Lantern sections" and "Lantern pages"
* Three styles (Clean, Bold, Warm), each with light and dark mode
* Light/dark follows each visitor's device, with a toggle; lock it under Appearance → Lantern options
* No page builder and no required plugins
* Styles the WPForms Lite and Contact Form 7 plugins to match

Full setup guide: see the docs included with your download.

== Installation ==

1. In WordPress, go to Appearance → Themes → Add New Theme → Upload Theme.
2. Choose the theme zip from the K&A download (the file whose name starts with "UPLOAD THIS") and click Install Now, then Activate.
3. Optional: import demo-content.xml (Tools → Import → WordPress) to get the demo pages.

== Frequently Asked Questions ==

= How do I change the main color? =

Appearance → Editor → Styles → Colors → Brand.

= How do I switch between Clean, Bold and Warm? =

Appearance → Editor → Styles, then pick a style.

= How do I keep the site always light or always dark? =

Appearance → Lantern options.

= How do I take donations? =

Lantern has a donation form spot on the Donate page. Paste in the embed code from a donation service such as Zeffy, Givebutter, Donorbox, PayPal or Stripe. The setup guide walks through it.

== Changelog ==

= 1.0.0 =
* First release.

== Copyright ==

Lantern WordPress Theme, Copyright 2026 K&A Digital Studio.
Lantern is distributed under the terms of the GNU GPL v2 or later.

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

Lantern bundles the following resources:

Icons: original icons by K&A Digital Studio, GPLv2 or later.
Placeholder images and the placeholder annual report: created by K&A Digital Studio, GPLv2 or later.
