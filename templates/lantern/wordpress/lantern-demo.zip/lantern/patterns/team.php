<?php
/**
 * Title: Team and board
 * Slug: lantern/team
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"section-head is-center","layout":{"type":"default"}} -->
<div class="wp-block-group section-head is-center"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Our team</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">The people behind the Pantry</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"13rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">DW</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Dana Whitfield</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Executive director</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">LO</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Luis Ortega</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Pantry manager</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">MC</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Mei Chen</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Volunteer coordinator</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">SB</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Sam Brooks</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Delivery coordinator</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Board of directors</h3>
<!-- /wp:heading --><!-- wp:list {"className":"board"} -->
<ul class="wp-block-list board">
<!-- wp:list-item -->
<li><strong>Grace Liu</strong>, Chair</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Marcus Hale</strong>, Treasurer</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Ana Pereira</strong>, Secretary</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Tom Becker</strong>, Member</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Joyce Adeyemi</strong>, Member</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Rev. Paul Kim</strong>, Member</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></section>
<!-- /wp:group -->
