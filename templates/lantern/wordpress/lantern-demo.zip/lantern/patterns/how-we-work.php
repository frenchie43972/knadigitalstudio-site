<?php
/**
 * Title: How we work
 * Slug: lantern/how-we-work
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:group {"className":"section-head is-center","layout":{"type":"default"}} -->
<div class="wp-block-group section-head is-center"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">How we work</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Dignity in every step</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"15rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"step","layout":{"type":"default"}} -->
<div class="wp-block-group step"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">1</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Rescue good food</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Grocers, farms and bakeries give us food that would go to waste. Volunteers sort it every day.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"step","layout":{"type":"default"}} -->
<div class="wp-block-group step"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">2</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Let people choose</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Guests shop for what their family will eat. Less waste, more dignity.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"step","layout":{"type":"default"}} -->
<div class="wp-block-group step"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">3</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Reach every neighbor</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Mobile pantries, summer sites and home delivery bring food to people who can’t come to us.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
