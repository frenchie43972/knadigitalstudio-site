<?php
/**
 * Title: Program page: Food pantry
 * Slug: lantern/program-food-pantry
 * Categories: lantern-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Food pantry</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Free groceries, chosen by you</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Our pantry is set up like a small market. You pick the food your family will eat: fresh produce, dairy, bread, meat and pantry staples.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-donate"} -->
<div class="wp-block-button is-donate"><a class="wp-block-button__link wp-element-button" href="/donate/">Support this program</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/volunteer/">Volunteer</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"top"} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top","width":"64%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:64%"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"lantern-photo"} -->
<figure class="wp-block-image size-large lantern-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/pantry.jpg' ) ); ?>" alt="Shelves of fresh produce and groceries at a community pantry"/></figure>
<!-- /wp:image --><!-- wp:heading -->
<h2 class="wp-block-heading">What you get</h2>
<!-- /wp:heading --><!-- wp:list {"className":"checklist is-cols"} -->
<ul class="wp-block-list checklist is-cols">
<!-- wp:list-item -->
<li>Fresh fruit and vegetables</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Milk, eggs and cheese</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Bread and baked goods</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Meat, fish and plant proteins</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Rice, pasta, cereal and canned goods</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Diapers, soap and period products</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --><!-- wp:heading -->
<h2 class="wp-block-heading">Who it’s for</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Anyone in Bayside and nearby towns who needs food. No proof of income needed.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">When and where</h2>
<!-- /wp:heading --><!-- wp:table {"hasFixedLayout":false,"className":"hours"} -->
<figure class="wp-block-table hours"><table><tbody><tr><td>Tuesday</td><td>3 p.m. – 7 p.m.</td></tr><tr><td>Thursday</td><td>10 a.m. – 2 p.m.</td></tr><tr><td>Saturday</td><td>9 a.m. – 12 p.m.</td></tr></tbody></table></figure>
<!-- /wp:table --><!-- wp:heading -->
<h2 class="wp-block-heading">Common questions</h2>
<!-- /wp:heading --><!-- wp:group {"className":"faq","layout":{"type":"default"}} -->
<div class="wp-block-group faq"><!-- wp:details -->
<details class="wp-block-details"><summary>How often can I come?</summary><!-- wp:paragraph -->
<p>Once a week, at any of our open hours. Fresh produce is out every day we’re open.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Can someone pick up for me?</summary><!-- wp:paragraph -->
<p>Yes. Send a family member or friend with your name, or call us to set up a regular pickup person.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:group {"className":"box box-glow fact","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group box box-glow fact"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#basket"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>1,850</strong>families shop with us each month</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"box box-brand","layout":{"type":"default"}} -->
<div class="wp-block-group box box-brand"><!-- wp:heading -->
<h2 class="wp-block-heading">Keep it going</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>This program runs on gifts from neighbors. $25 provides 75 meals.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-donate"} -->
<div class="wp-block-button is-donate"><a class="wp-block-button__link wp-element-button" href="/donate/">Donate</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --><!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Questions?</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Call us on weekdays, 9 a.m. to 5 p.m.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:+15035550187">(503) 555-0187</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"lantern/cta"} /-->
