<?php
/**
 * Title: Donate page
 * Slug: lantern/page-donate
 * Categories: lantern-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Donate</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Your gift feeds a neighbor tonight</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Every dollar provides three meals. Give once or monthly; it’s secure and tax-deductible.</p>
<!-- /wp:paragraph --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"top"} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top","width":"62%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:62%"><!-- wp:pattern {"slug":"lantern/donation-form-slot"} /--></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:pattern {"slug":"lantern/campaign"} /--><!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Most needed food</h3>
<!-- /wp:heading --><!-- wp:list {"className":"checklist"} -->
<ul class="wp-block-list checklist">
<!-- wp:list-item -->
<li>Peanut butter</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Canned tuna and chicken</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Cereal and oatmeal</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Rice and pasta</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Diapers (sizes 4–6)</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Period products</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"lantern/gifts"} /--><!-- wp:pattern {"slug":"lantern/ways-to-give"} /--><!-- wp:pattern {"slug":"lantern/faq"} /-->
