<?php
/**
 * Title: Other ways to give
 * Slug: lantern/ways-to-give
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"section-head","layout":{"type":"default"}} -->
<div class="wp-block-group section-head"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Other ways to give</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">More ways to help</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"16rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"way","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group way"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#repeat"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Give monthly</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Monthly gifts let us plan ahead. $15 a month feeds a family every week of the year.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"way","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group way"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#mail"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Mail a check</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Make it out to Bayside Community Pantry and mail it to 48 Mill Street, Bayside, OR 97000.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"way","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group way"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#building"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Double it at work</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Many employers match gifts. Ask your HR team, and use our EIN below.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"way","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group way"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#basket"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Donate food</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Bring food to the Pantry during open hours. Peanut butter, canned fish and cereal are needed most.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"way","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group way"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#gift"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Host a food drive</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>At school, work or church. We’ll lend you bins and pick up the food.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"way","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group way"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#heart"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Give in someone’s name</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Honor or remember someone special. We’ll send them, or their family, a card.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
