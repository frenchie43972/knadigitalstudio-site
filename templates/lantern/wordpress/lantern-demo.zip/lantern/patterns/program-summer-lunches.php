<?php
/**
 * Title: Program page: Summer lunches for kids
 * Slug: lantern/program-summer-lunches
 * Categories: lantern-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Summer lunches for kids</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Free summer lunches for every kid</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">When school meals stop for the summer, many kids go without. We serve free lunches at six parks and libraries across Bayside, every weekday from June to August.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-donate"} -->
<div class="wp-block-button is-donate"><a class="wp-block-button__link wp-element-button" href="/donate/">Support this program</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/volunteer/">Volunteer</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"top"} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top","width":"64%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:64%"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"lantern-photo"} -->
<figure class="wp-block-image size-large lantern-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/kids.jpg' ) ); ?>" alt="Children eating lunch together at an outdoor picnic table"/></figure>
<!-- /wp:image --><!-- wp:heading -->
<h2 class="wp-block-heading">What you get</h2>
<!-- /wp:heading --><!-- wp:list {"className":"checklist is-cols"} -->
<ul class="wp-block-list checklist is-cols">
<!-- wp:list-item -->
<li>A healthy lunch with fruit and milk</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Six sites in parks and libraries</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Games and reading at every site</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>No forms, no sign-up</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --><!-- wp:heading -->
<h2 class="wp-block-heading">Who it’s for</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Any child 18 or under. Parents and caregivers can eat for $1.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">When and where</h2>
<!-- /wp:heading --><!-- wp:table {"hasFixedLayout":false,"className":"hours"} -->
<figure class="wp-block-table hours"><table><tbody><tr><td>When</td><td>Monday – Friday, June 16 – August 22</td></tr><tr><td>Time</td><td>11:30 a.m. – 1 p.m.</td></tr><tr><td>Sites</td><td>Harbor Park, Northgate Library, Cedar Hill Pool and 3 more</td></tr></tbody></table></figure>
<!-- /wp:table --><!-- wp:heading -->
<h2 class="wp-block-heading">Common questions</h2>
<!-- /wp:heading --><!-- wp:group {"className":"faq","layout":{"type":"default"}} -->
<div class="wp-block-group faq"><!-- wp:details -->
<details class="wp-block-details"><summary>Does my child need to be signed up?</summary><!-- wp:paragraph -->
<p>No. Kids just show up at any site. There are no forms.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Are there options for allergies?</summary><!-- wp:paragraph -->
<p>Yes. Tell the site leader; we keep nut-free and dairy-free lunches at every site.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:group {"className":"box box-glow fact","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group box box-glow fact"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#apple"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>14,200</strong>lunches served last summer</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"box box-brand","layout":{"type":"default"}} -->
<div class="wp-block-group box box-brand"><!-- wp:heading -->
<h2 class="wp-block-heading">Keep it going</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>This program runs on gifts from neighbors. $25 provides 75 meals.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-donate"} -->
<div class="wp-block-button is-donate"><a class="wp-block-button__link wp-element-button" href="/donate/">Donate</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --><!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Questions?</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Call us on weekdays, 9 a.m. to 5 p.m.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:+15035550187">(503) 555-0187</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"lantern/cta"} /-->
