<?php
/**
 * Title: Events page
 * Slug: lantern/page-events
 * Categories: lantern-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Events</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Come along, bring a friend</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Food drives, fun runs and volunteer evenings. Every event helps fill the shelves.</p>
<!-- /wp:paragraph --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"event","layout":{"type":"flex","flexWrap":"wrap","verticalAlignment":"center"},"anchor":"turkey-drive"} -->
<div id="turkey-drive" class="wp-block-group event"><!-- wp:paragraph {"className":"date"} -->
<p class="date">Nov<br><strong>14</strong></p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Turkey &amp; Trimmings Drive</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Drop off a frozen turkey or holiday sides. Volunteers will be there to unload your car.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"event-meta"} -->
<p class="event-meta">Saturday, 9 a.m. – 1 p.m. · Bayside Market parking lot</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="https://www.google.com/maps/search/?api=1&amp;query=300+Harbor+Way+Bayside">Get directions</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --><!-- wp:group {"className":"event","layout":{"type":"flex","flexWrap":"wrap","verticalAlignment":"center"},"anchor":"volunteer-orientation"} -->
<div id="volunteer-orientation" class="wp-block-group event"><!-- wp:paragraph {"className":"date"} -->
<p class="date">Nov<br><strong>21</strong></p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">New volunteer orientation</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>A friendly hour on how the Pantry works, followed by a tour. Bring a friend.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"event-meta"} -->
<p class="event-meta">Saturday, 10 a.m. – 11:30 a.m. · Bayside Community Pantry</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="volunteer.html#signup">Sign up</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --><!-- wp:group {"className":"event","layout":{"type":"flex","flexWrap":"wrap","verticalAlignment":"center"},"anchor":"lights-5k"} -->
<div id="lights-5k" class="wp-block-group event"><!-- wp:paragraph {"className":"date"} -->
<p class="date">Dec<br><strong>5</strong></p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Holiday Lights 5K for Hunger</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Walk or run through the park lights. $25 entry feeds a family for a week.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"event-meta"} -->
<p class="event-meta">Saturday, 4 p.m. – 7 p.m. · Harbor Park</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="https://www.example.com/5k">Register</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --><!-- wp:group {"className":"event","layout":{"type":"flex","flexWrap":"wrap","verticalAlignment":"center"},"anchor":"gift-wrap"} -->
<div id="gift-wrap" class="wp-block-group event"><!-- wp:paragraph {"className":"date"} -->
<p class="date">Dec<br><strong>12</strong></p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Wrap &amp; Give</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Bring your gifts, we’ll wrap them. Every donation goes to the winter appeal.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"event-meta"} -->
<p class="event-meta">Saturday, 11 a.m. – 4 p.m. · Northgate Library</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="https://www.google.com/maps/search/?api=1&amp;query=75+Elm+Avenue+Northgate">Get directions</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Past events</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Thanks to everyone who came</h2>
<!-- /wp:heading --><!-- wp:list {"className":"checklist"} -->
<ul class="wp-block-list checklist">
<!-- wp:list-item -->
<li>Spring Food Fest: 2,300 pounds of food collected</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Summer lunch kickoff at Harbor Park</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Fill the Bus back-to-school drive</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:group {"className":"box box-brand","layout":{"type":"default"}} -->
<div class="wp-block-group box box-brand"><!-- wp:heading -->
<h2 class="wp-block-heading">Host your own drive</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Run a food drive or fundraiser at school, work or church. We’ll lend you bins and posters, and pick up the food.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contact/">Tell us about your idea</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
