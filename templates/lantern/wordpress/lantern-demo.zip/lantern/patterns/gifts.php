<?php
/**
 * Title: Your gift at work
 * Slug: lantern/gifts
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:group {"className":"section-head is-center","layout":{"type":"default"}} -->
<div class="wp-block-group section-head is-center"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Your gift at work</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">See what your gift does</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Every dollar provides three meals. Pick an amount, or give what feels right.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"15rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"gift","layout":{"type":"default"}} -->
<div class="wp-block-group gift"><!-- wp:paragraph {"className":"gift-amount"} -->
<p class="gift-amount">$25</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Groceries for a family for a week</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/donate/">Give $25 →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"gift is-featured","layout":{"type":"default"}} -->
<div class="wp-block-group gift is-featured"><!-- wp:paragraph {"className":"gift-amount"} -->
<p class="gift-amount">$50</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Fresh fruit and vegetables for 10 families</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/donate/">Give $50 →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"gift","layout":{"type":"default"}} -->
<div class="wp-block-group gift"><!-- wp:paragraph {"className":"gift-amount"} -->
<p class="gift-amount">$100</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>A hot Wednesday dinner for 40 neighbors</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/donate/">Give $100 →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"gift","layout":{"type":"default"}} -->
<div class="wp-block-group gift"><!-- wp:paragraph {"className":"gift-amount"} -->
<p class="gift-amount">$250</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Three months of grocery delivery for a senior</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/donate/">Give $250 →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:paragraph {"className":"has-text-align-center has-soft-text","align":"center"} -->
<p class="has-text-align-center has-soft-text">Tax-deductible · Secure · Monthly or one-time · <a href="/donate/">All ways to give →</a></p>
<!-- /wp:paragraph --></section>
<!-- /wp:group -->
