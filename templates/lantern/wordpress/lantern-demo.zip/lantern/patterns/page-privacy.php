<?php
/**
 * Title: Privacy policy page
 * Slug: lantern/page-privacy
 * Categories: lantern-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Legal</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Privacy policy</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Last updated: [date]. This is a starting point. Have it reviewed for your organization and location.</p>
<!-- /wp:paragraph --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading -->
<h2 class="wp-block-heading">What we collect</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>When you get food, volunteer, donate, sign up for our newsletter or contact us, we collect the details you give us, such as your name, address, email, phone number and household size.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">How we use it</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Only to provide our programs, arrange volunteering, process and receipt donations, send the newsletter you asked for, and report anonymous totals to our funders. We don’t sell or rent your information.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Donations</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Online gifts are handled by our donation provider. We never see or store your full card number.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Who we share it with</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Only with services that help us run the organization, such as our donation, email and form providers, and only as needed for those services. Information about the people we serve is never shared.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">How long we keep it</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>As long as we need it for our programs and records, or as required by law.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Your choices</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>You can ask to see, correct or delete your information, or unsubscribe from emails, at any time by writing to <a href="mailto:hello@example.com">hello@example.com</a>.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
