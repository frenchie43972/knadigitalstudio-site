<?php
/**
 * Title: Hero with photo and campaign meter
 * Slug: lantern/hero
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section hero"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center","width":"48%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:48%"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Food for every neighbor</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">No one in Bayside should go to bed hungry</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">We share free groceries, hot meals and a warm welcome with 1,850 families every month. Your gift or a few hours of your time keeps the shelves full.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-donate"} -->
<div class="wp-block-button is-donate"><a class="wp-block-button__link wp-element-button" href="/donate/">Donate</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/volunteer/">Volunteer with us</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:group {"className":"hero-media","layout":{"type":"default"}} -->
<div class="wp-block-group hero-media"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"lantern-photo is-hero"} -->
<figure class="wp-block-image size-large lantern-photo is-hero"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/hero.jpg' ) ); ?>" alt="Volunteers smiling as they pack boxes of fresh food"/></figure>
<!-- /wp:image --><!-- wp:group {"className":"campaign","layout":{"type":"default"}} -->
<div class="wp-block-group campaign"><!-- wp:heading -->
<h2 class="wp-block-heading">Winter appeal</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Every gift before December 31 is matched, up to $10,000, by Harbor Home Services.</p>
<!-- /wp:paragraph --><!-- wp:html -->
<!-- Goal meter: change 74% to your percentage, and update the amounts below. -->
<div class="meter" role="img" aria-label="$18,400 raised of a $25,000 goal, 74 percent"><span style="--progress: 74%"></span></div>
<!-- /wp:html --><!-- wp:paragraph {"className":"meter-nums"} -->
<p class="meter-nums"><span><strong>$18,400</strong> raised</span><span>Goal $25,000</span></p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/donate/">Give to the appeal →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
