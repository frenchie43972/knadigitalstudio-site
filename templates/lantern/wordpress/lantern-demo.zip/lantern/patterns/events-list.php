<?php
/**
 * Title: Upcoming events
 * Slug: lantern/events-list
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"section-head","layout":{"type":"default"}} -->
<div class="wp-block-group section-head"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Upcoming events</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Join us this season</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"className":"event","layout":{"type":"flex","flexWrap":"wrap","verticalAlignment":"center"}} -->
<div class="wp-block-group event"><!-- wp:paragraph {"className":"date"} -->
<p class="date">Nov<br><strong>14</strong></p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Turkey &amp; Trimmings Drive</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"event-meta"} -->
<p class="event-meta">Saturday, 9 a.m. – 1 p.m. · Bayside Market parking lot</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/events/#turkey-drive">Details</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --><!-- wp:group {"className":"event","layout":{"type":"flex","flexWrap":"wrap","verticalAlignment":"center"}} -->
<div class="wp-block-group event"><!-- wp:paragraph {"className":"date"} -->
<p class="date">Nov<br><strong>21</strong></p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">New volunteer orientation</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"event-meta"} -->
<p class="event-meta">Saturday, 10 a.m. – 11:30 a.m. · Bayside Community Pantry</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/events/#volunteer-orientation">Details</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --><!-- wp:group {"className":"event","layout":{"type":"flex","flexWrap":"wrap","verticalAlignment":"center"}} -->
<div class="wp-block-group event"><!-- wp:paragraph {"className":"date"} -->
<p class="date">Dec<br><strong>5</strong></p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Holiday Lights 5K for Hunger</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"event-meta"} -->
<p class="event-meta">Saturday, 4 p.m. – 7 p.m. · Harbor Park</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/events/#lights-5k">Details</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/events/">All events →</a></p>
<!-- /wp:paragraph --></section>
<!-- /wp:group -->
