<?php
/**
 * Title: Campaign goal meter
 * Slug: lantern/campaign
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"className":"campaign","layout":{"type":"default"}} -->
<div class="wp-block-group campaign"><!-- wp:heading -->
<h2 class="wp-block-heading">Winter appeal</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Every gift before December 31 is matched, up to $10,000, by Harbor Home Services.</p>
<!-- /wp:paragraph --><!-- wp:html -->
<!-- Goal meter: change 74% to your percentage, and update the amounts below. -->
<div class="meter" role="img" aria-label="$18,400 raised of a $25,000 goal, 74 percent"><span style="--progress: 74%"></span></div>
<!-- /wp:html --><!-- wp:paragraph {"className":"meter-nums"} -->
<p class="meter-nums"><span><strong>$18,400</strong> raised</span><span>Goal $25,000</span></p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/donate/">Give to the appeal →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
