<?php
/**
 * Title: Where the money goes
 * Slug: lantern/money
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center","width":"45%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Where your money goes</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">92¢ of every dollar goes straight to food</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">We keep costs low with volunteers and donated space, so your gift goes to the people it’s for.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:html -->
<!-- Money breakdown: change each --share percentage and the matching number in the list below (they should add up to 100). -->
<div class="money-bar" role="img" aria-label="Programs: food, meals and delivery: 92 percent, Running the Pantry: rent, insurance, accounting: 5 percent, Fundraising: 3 percent"><span style="--share: 92%"></span><span style="--share: 5%"></span><span style="--share: 3%"></span></div>
<!-- /wp:html --><!-- wp:list {"className":"money-key"} -->
<ul class="wp-block-list money-key">
<!-- wp:list-item -->
<li>Programs: food, meals and delivery <strong>92%</strong></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Running the Pantry: rent, insurance, accounting <strong>5%</strong></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Fundraising <strong>3%</strong></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --><!-- wp:paragraph {"className":"seal"} -->
<p class="seal"><strong>Audited every year</strong>Our latest annual report and audited accounts are public.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
