<?php
/**
 * Title: Contact details and hours
 * Slug: lantern/contact-details
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading -->
<h2 class="wp-block-heading">Call or visit</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"line-phone"} -->
<p class="line-phone"><strong>Phone:</strong> <a href="tel:+15035550187">(503) 555-0187</a></p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"line-mail"} -->
<p class="line-mail"><strong>Email:</strong> <a href="mailto:hello@example.com">hello@example.com</a></p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"line-pin"} -->
<p class="line-pin"><strong>The Pantry:</strong> <a href="https://www.google.com/maps/search/?api=1&amp;query=48+Mill+Street+Bayside">48 Mill Street, Bayside</a></p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p><a href="https://www.google.com/maps/search/?api=1&amp;query=48+Mill+Street+Bayside"><strong>Get directions →</strong></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Office hours</h3>
<!-- /wp:heading --><!-- wp:table {"hasFixedLayout":false,"className":"hours"} -->
<figure class="wp-block-table hours"><table><tbody><tr><td>Monday – Friday</td><td>9 a.m. – 5 p.m.</td></tr><tr><td>Food drop-off</td><td>Tue – Sat, during pantry hours</td></tr><tr><td>Sunday</td><td>Closed</td></tr></tbody></table></figure>
<!-- /wp:table --></div>
<!-- /wp:group --><!-- wp:group {"className":"box box-glow","layout":{"type":"default"}} -->
<div class="wp-block-group box box-glow"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Mailing a check?</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Bayside Community Pantry<br>48 Mill Street<br>Bayside, OR 97000</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
