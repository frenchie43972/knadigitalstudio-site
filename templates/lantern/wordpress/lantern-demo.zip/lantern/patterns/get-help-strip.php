<?php
/**
 * Title: Get help strip
 * Slug: lantern/get-help-strip
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:group {"className":"help","layout":{"type":"default"}} -->
<div class="wp-block-group help"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center","width":"55%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:55%"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Need food?</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">You’re welcome here</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Free groceries every week for anyone who needs them. No proof of income, no appointment. Se habla español.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/get-help/">How to get food</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:+15035550187">(503) 555-0187</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:paragraph {"className":"hours-title"} -->
<p class="hours-title">Pantry hours at 48 Mill Street</p>
<!-- /wp:paragraph --><!-- wp:table {"hasFixedLayout":false,"className":"hours"} -->
<figure class="wp-block-table hours"><table><tbody><tr><td>Tuesday</td><td>3 p.m. – 7 p.m.</td></tr><tr><td>Thursday</td><td>10 a.m. – 2 p.m.</td></tr><tr><td>Saturday</td><td>9 a.m. – 12 p.m.</td></tr></tbody></table></figure>
<!-- /wp:table --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
