<?php
/**
 * Title: A story
 * Slug: lantern/story
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"lantern-photo is-tall"} -->
<figure class="wp-block-image size-large lantern-photo is-tall"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/story.jpg' ) ); ?>" alt="A smiling volunteer handing a bag of groceries across a table"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">A neighbor’s story</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"story-quote"} -->
<p class="story-quote">When I lost my job, the Pantry kept my kids fed. Nobody made me feel small. Now I volunteer on Saturdays, because I know what that welcome means.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"story-cite"} -->
<p class="story-cite"><strong>Rosa M.</strong>Pantry guest, now a Saturday volunteer</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/our-impact/">More stories</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
