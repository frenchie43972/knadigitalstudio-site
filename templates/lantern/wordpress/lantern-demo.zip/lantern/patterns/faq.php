<?php
/**
 * Title: Questions and answers
 * Slug: lantern/faq
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:group {"className":"section-head is-center","layout":{"type":"default"}} -->
<div class="wp-block-group section-head is-center"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Questions</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Giving, answered</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"className":"faq","layout":{"type":"default"}} -->
<div class="wp-block-group faq"><!-- wp:details -->
<details class="wp-block-details"><summary>Is my gift tax-deductible?</summary><!-- wp:paragraph -->
<p>Yes. Bayside Community Pantry is a 501(c)(3) nonprofit, EIN 93-1234567. Gifts are tax-deductible as allowed by law, and you’ll get a receipt by email.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Is giving online secure?</summary><!-- wp:paragraph -->
<p>Yes. Gifts are handled by our donation provider on a secure page. We never see or store your card number.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Can I change or cancel a monthly gift?</summary><!-- wp:paragraph -->
<p>Any time. Use the link in your receipt email, or call us and we’ll do it for you.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Can I give food or time instead?</summary><!-- wp:paragraph -->
<p>Yes, and thank you. See “Other ways to give” above, or visit our volunteer page.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
