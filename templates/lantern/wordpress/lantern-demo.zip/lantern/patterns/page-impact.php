<?php
/**
 * Title: Our impact page
 * Slug: lantern/page-impact
 * Categories: lantern-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Our impact</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">What we did together last year</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Thanks to 640 volunteers and thousands of donors, here’s what our community shared in 2025.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( get_theme_file_uri( 'assets/annual-report.pdf' ) ); ?>">Download the annual report (PDF)</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"lantern/impact"} /--><!-- wp:pattern {"slug":"lantern/money"} /--><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"section-head is-center","layout":{"type":"default"}} -->
<div class="wp-block-group section-head is-center"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Stories</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">In our neighbors’ words</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"16rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">A first visit</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"story-small"} -->
<p class="story-small">“I didn’t know what to expect. A volunteer walked me through it and helped me find food my son could eat with his allergies.”</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">Amira, Bayside</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">A Friday visitor</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"story-small"} -->
<p class="story-small">“My driver, Joan, comes every week. She brings the groceries in and stays for a coffee. Some weeks she’s the only person I see.”</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">Walter, 84, Millbrook</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">A summer site</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"story-small"} -->
<p class="story-small">“The lunch program fed my three kids all summer. They loved the reading corner at the library.”</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">Keisha, Northgate</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"lantern/partners"} /--><!-- wp:pattern {"slug":"lantern/cta"} /-->
