<?php
/**
 * Title: Our values
 * Slug: lantern/values
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:group {"className":"section-head is-center","layout":{"type":"default"}} -->
<div class="wp-block-group section-head is-center"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">What we believe</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Four values guide everything we do</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"14rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#heart"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Dignity first</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Everyone chooses their own food and is welcomed by name. No one has to prove they’re hungry.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#users"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Neighbors helping neighbors</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Most of our volunteers live within a mile of the Pantry, and many once came for help themselves.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#sprout"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Waste nothing</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>We rescue 300,000 pounds of good food from grocers and farms each year.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#report"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Open books</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Our finances and annual report are public. Ask us anything.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
