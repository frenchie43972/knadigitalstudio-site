<?php
/**
 * Title: Partners
 * Slug: lantern/partners
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"section-head is-center","layout":{"type":"default"}} -->
<div class="wp-block-group section-head is-center"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Partners</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">We couldn’t do it alone</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Local businesses, farms, schools and faith groups give food, space and time.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:list {"className":"partners"} -->
<ul class="wp-block-list partners">
<!-- wp:list-item -->
<li>Bayside Market</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Harbor Home Services</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Millbrook Farms</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Cedar Hill Rotary</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Northgate Library</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>St. Anne’s Church</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Bayside Credit Union</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Lakeview Schools</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></section>
<!-- /wp:group -->
