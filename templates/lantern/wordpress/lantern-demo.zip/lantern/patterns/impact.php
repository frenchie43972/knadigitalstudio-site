<?php
/**
 * Title: Impact numbers
 * Slug: lantern/impact
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section impact","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section impact"><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"12rem"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"impact-item"} -->
<p class="impact-item"><strong>412,000</strong>meals shared last year</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"impact-item"} -->
<p class="impact-item"><strong>1,850</strong>families each month</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"impact-item"} -->
<p class="impact-item"><strong>640</strong>volunteers</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"impact-item"} -->
<p class="impact-item"><strong>92¢</strong>of every dollar goes to programs</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
