<?php
/**
 * Title: Donation form spot
 * Slug: lantern/donation-form-slot
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading -->
<h2 class="wp-block-heading">Make a gift</h2>
<!-- /wp:heading --><!-- wp:html -->
<!-- Paste the embed code from your donation tool (Zeffy, Givebutter, Donorbox, PayPal or Stripe) in place of this box. -->
<div class="embed-slot"><svg class="icon" aria-hidden="true"><use href="#heart"></use></svg><strong>Your donation form goes here</strong><span>See “Donations” in the Lantern guide.</span></div>
<!-- /wp:html --><!-- wp:paragraph {"className":"has-soft-text has-small-font-size"} -->
<p class="has-soft-text has-small-font-size">Bayside Community Pantry is a 501(c)(3) nonprofit, EIN 93-1234567. Gifts are tax-deductible as allowed by law.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
