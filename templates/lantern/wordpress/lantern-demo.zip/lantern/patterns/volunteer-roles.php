<?php
/**
 * Title: Volunteer roles
 * Slug: lantern/volunteer-roles
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"section-head","layout":{"type":"default"}} -->
<div class="wp-block-group section-head"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Roles</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Find a role that fits</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"16rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#basket"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Pantry helper</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Stock shelves, greet guests and help people find what they need.</p>
<!-- /wp:paragraph --><!-- wp:list {"className":"tags"} -->
<ul class="wp-block-list tags">
<!-- wp:list-item -->
<li>Tue, Thu, Sat</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>2–3 hours</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Ages 14+</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#bowl"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Meal server</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Set tables, serve dinner and clean up on Wednesday evenings.</p>
<!-- /wp:paragraph --><!-- wp:list {"className":"tags"} -->
<ul class="wp-block-list tags">
<!-- wp:list-item -->
<li>Wednesdays</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>5–8 p.m.</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Ages 12+ with an adult</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#truck"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Delivery driver</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Deliver grocery boxes to seniors on Friday mornings. Use your own car.</p>
<!-- /wp:paragraph --><!-- wp:list {"className":"tags"} -->
<ul class="wp-block-list tags">
<!-- wp:list-item -->
<li>Fridays</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>2 hours</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Driver’s license</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#apple"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Summer lunch helper</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Hand out lunches and run games at a park or library site.</p>
<!-- /wp:paragraph --><!-- wp:list {"className":"tags"} -->
<ul class="wp-block-list tags">
<!-- wp:list-item -->
<li>June – August</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Weekdays</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Ages 16+</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#chat"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Office and phones</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Answer calls, book deliveries and help with mailings.</p>
<!-- /wp:paragraph --><!-- wp:list {"className":"tags"} -->
<ul class="wp-block-list tags">
<!-- wp:list-item -->
<li>Weekday mornings</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>3 hours</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Ages 18+</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#users"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Groups and companies</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Bring a team of 5 to 25 for a sorting shift. A great team day.</p>
<!-- /wp:paragraph --><!-- wp:list {"className":"tags"} -->
<ul class="wp-block-list tags">
<!-- wp:list-item -->
<li>Weekdays</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>3 hours</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Book ahead</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
