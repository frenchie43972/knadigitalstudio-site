<?php
/**
 * Title: About page
 * Slug: lantern/page-about
 * Categories: lantern-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">About us</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Neighbors feeding neighbors since 1994</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">What began as one shelf in a church basement is now Bayside’s community pantry, run by a small team and hundreds of volunteers.</p>
<!-- /wp:paragraph --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"lantern-photo is-tall"} -->
<figure class="wp-block-image size-large lantern-photo is-tall"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/about.jpg' ) ); ?>" alt="Volunteers sorting donated food in a warehouse"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Our story</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">It started with one shelf</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>In the winter of 1994, members of St. Anne’s Church noticed that more families were asking for help with food. They cleared a shelf in the basement and filled it with cans.</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Word spread. Grocers began giving food that would otherwise be thrown away, and neighbors began giving their time. Today we share more than 400,000 meals a year from our home on Mill Street.</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p><strong>Our mission:</strong> make sure no one in Bayside goes hungry, and that everyone who comes to us is treated as a neighbor.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"lantern/values"} /--><!-- wp:pattern {"slug":"lantern/team"} /--><!-- wp:pattern {"slug":"lantern/cta"} /-->
