<?php
/**
 * Title: Get help page
 * Slug: lantern/page-get-help
 * Categories: lantern-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Get help</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Free food for you and your family</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Anyone who needs food is welcome. No proof of income, no appointment, no judgment. Come during open hours, or call us.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="tel:+15035550187">Call (503) 555-0187</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="https://www.google.com/maps/search/?api=1&amp;query=48+Mill+Street+Bayside">Get directions</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"help","layout":{"type":"default"}} -->
<div class="wp-block-group help"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center","width":"55%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:55%"><!-- wp:heading -->
<h2 class="wp-block-heading">Who can come</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Anyone in Bayside and nearby towns who needs food. On your first visit, bring something with your name and address if you have it. If you don’t, come anyway.</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p><strong>¿Necesita comida?</strong> Hablamos español. Venga en nuestro horario o llámenos.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:paragraph {"className":"hours-title"} -->
<p class="hours-title">Pantry hours at 48 Mill Street</p>
<!-- /wp:paragraph --><!-- wp:table {"hasFixedLayout":false,"className":"hours"} -->
<figure class="wp-block-table hours"><table><tbody><tr><td>Tuesday</td><td>3 p.m. – 7 p.m.</td></tr><tr><td>Thursday</td><td>10 a.m. – 2 p.m.</td></tr><tr><td>Saturday</td><td>9 a.m. – 12 p.m.</td></tr></tbody></table></figure>
<!-- /wp:table --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:group {"className":"section-head is-center","layout":{"type":"default"}} -->
<div class="wp-block-group section-head is-center"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Your first visit</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">What to expect</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"15rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"step","layout":{"type":"default"}} -->
<div class="wp-block-group step"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">1</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Check in</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Tell the volunteer at the front desk your name and address. It takes two minutes.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"step","layout":{"type":"default"}} -->
<div class="wp-block-group step"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">2</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Shop</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Take a cart and choose your food, like in a store. Volunteers can help.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"step","layout":{"type":"default"}} -->
<div class="wp-block-group step"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">3</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Come back</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Visit once a week. Fresh produce is out every day we’re open.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"section-head","layout":{"type":"default"}} -->
<div class="wp-block-group section-head"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Where to find us</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">One pantry, two mobile stops</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"16rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"way","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group way"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#pin"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Main pantry</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>48 Mill Street, Bayside<br><strong>Tue 3–7 p.m. · Thu 10 a.m.–2 p.m. · Sat 9 a.m.–12 p.m.</strong></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"way","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group way"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#pin"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Mobile pantry: Northgate</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Northgate Library, 75 Elm Avenue<br><strong>First Monday of the month, 4–6 p.m.</strong></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"way","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group way"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#pin"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Mobile pantry: Cedar Hill</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Cedar Hill Community Center, 12 Ridge Road<br><strong>Third Monday of the month, 4–6 p.m.</strong></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:columns {"verticalAlignment":"top"} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">More help</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Other help nearby</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Food is often just one worry. Our team can point you to the right place.</p>
<!-- /wp:paragraph --><!-- wp:list {"className":"checklist"} -->
<ul class="wp-block-list checklist">
<!-- wp:list-item -->
<li><strong>Food stamps (SNAP):</strong> We help you apply, Thursdays 10 a.m. – 2 p.m.</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Housing, bills and health care:</strong> Call 211, free and confidential, any time</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Women, infants and children (WIC):</strong> Ask at the front desk for the nearest WIC office</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:heading -->
<h2 class="wp-block-heading">Common questions</h2>
<!-- /wp:heading --><!-- wp:group {"className":"faq","layout":{"type":"default"}} -->
<div class="wp-block-group faq"><!-- wp:details -->
<details class="wp-block-details"><summary>Do I need to show ID or proof of income?</summary><!-- wp:paragraph -->
<p>No proof of income. On your first visit, bring something with your name and address if you have it, like a letter or ID. If you don’t, come anyway.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Is it confidential?</summary><!-- wp:paragraph -->
<p>Yes. We only keep your name, address and household size, and we never share them.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>I have diet needs. Can you help?</summary><!-- wp:paragraph -->
<p>Yes. We stock gluten-free, low-sugar, halal and baby food. Ask a volunteer and we’ll find what works.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Do you speak my language?</summary><!-- wp:paragraph -->
<p>Our volunteers speak English, Spanish and Vietnamese, and we can get an interpreter by phone for any language.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
