<?php
/**
 * Title: Volunteer page
 * Slug: lantern/page-volunteer
 * Categories: lantern-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Volunteer</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Give two hours, feed a family</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">640 neighbors volunteer with us. No experience needed: every shift starts with a welcome and a buddy.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#signup">Sign up to volunteer</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/events/#volunteer-orientation">Come to an orientation</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"lantern/volunteer-roles"} /--><!-- wp:group {"tagName":"section","anchor":"signup","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section id="signup" class="wp-block-group alignfull section is-soft"><!-- wp:columns {"verticalAlignment":"top"} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top","width":"62%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:62%"><!-- wp:pattern {"slug":"lantern/volunteer-form-slot"} /--></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:group {"className":"box box-glow fact","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group box box-glow fact"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#users"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>640</strong>volunteers gave 21,000 hours last year</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Questions?</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Mei, our volunteer coordinator, is happy to help.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="mailto:hello@example.com">Email Mei</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"section-head is-center","layout":{"type":"default"}} -->
<div class="wp-block-group section-head is-center"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Questions</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Volunteering, answered</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"className":"faq","layout":{"type":"default"}} -->
<div class="wp-block-group faq"><!-- wp:details -->
<details class="wp-block-details"><summary>Do I need experience?</summary><!-- wp:paragraph -->
<p>No. Every shift starts with a short welcome, and an experienced volunteer works alongside you.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>How old do I need to be?</summary><!-- wp:paragraph -->
<p>14 for pantry shifts, 12 with an adult for meals, 18 for driving and office work.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Can I volunteer once, or does it have to be regular?</summary><!-- wp:paragraph -->
<p>Either. Many people come once a month; others come every week.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Can I get community service hours?</summary><!-- wp:paragraph -->
<p>Yes. We’ll sign forms for school, court and work programs.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
