<?php
/**
 * Title: Contact form spot
 * Slug: lantern/contact-form-slot
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading -->
<h2 class="wp-block-heading">Send a message</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">Add your contact form here. Install a free form plugin such as WPForms Lite or Contact Form 7, create a form, then replace this box with the form’s block or shortcode. Lantern styles both plugins to match.</p>
<!-- /wp:paragraph --><!-- wp:html -->
<div class="embed-slot"><svg class="icon" aria-hidden="true"><use href="#mail"></use></svg><strong>Your contact form goes here</strong><span>See “Forms” in the Lantern guide.</span></div>
<!-- /wp:html --></div>
<!-- /wp:group -->
