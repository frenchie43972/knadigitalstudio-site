<?php
/**
 * Title: Volunteer form spot
 * Slug: lantern/volunteer-form-slot
 * Categories: lantern
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading -->
<h2 class="wp-block-heading">Sign up</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Tell us a little about you and we’ll be in touch within two days to find your first shift.</p>
<!-- /wp:paragraph --><!-- wp:html -->
<div class="embed-slot"><svg class="icon" aria-hidden="true"><use href="#users"></use></svg><strong>Your volunteer form goes here</strong><span>Use a form plugin, or paste a SignUpGenius or Google Forms link. See “Forms” in the Lantern guide.</span></div>
<!-- /wp:html --></div>
<!-- /wp:group -->
