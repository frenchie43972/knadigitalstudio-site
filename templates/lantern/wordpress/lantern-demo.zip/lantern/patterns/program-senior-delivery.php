<?php
/**
 * Title: Program page: Grocery delivery for seniors
 * Slug: lantern/program-senior-delivery
 * Categories: lantern-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Grocery delivery for seniors</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Groceries at the door for seniors who can’t get out</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Our volunteer drivers bring a box of groceries every Friday to seniors and neighbors with a disability. Each visit is also a friendly check-in.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-donate"} -->
<div class="wp-block-button is-donate"><a class="wp-block-button__link wp-element-button" href="/donate/">Support this program</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/volunteer/">Volunteer</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"top"} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top","width":"64%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:64%"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"lantern-photo"} -->
<figure class="wp-block-image size-large lantern-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/delivery.jpg' ) ); ?>" alt="A volunteer carrying a box of groceries to a front door"/></figure>
<!-- /wp:image --><!-- wp:heading -->
<h2 class="wp-block-heading">What you get</h2>
<!-- /wp:heading --><!-- wp:list {"className":"checklist is-cols"} -->
<ul class="wp-block-list checklist is-cols">
<!-- wp:list-item -->
<li>A weekly box chosen for your diet</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Fresh produce, dairy and protein</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Delivered by the same friendly driver</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>A check-in call if we can’t reach you</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --><!-- wp:heading -->
<h2 class="wp-block-heading">Who it’s for</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Bayside residents aged 60 and over, or anyone with a disability that makes shopping hard.</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">When and where</h2>
<!-- /wp:heading --><!-- wp:table {"hasFixedLayout":false,"className":"hours"} -->
<figure class="wp-block-table hours"><table><tbody><tr><td>Delivery day</td><td>Friday mornings</td></tr><tr><td>Sign up</td><td>Call (503) 555-0187</td></tr></tbody></table></figure>
<!-- /wp:table --><!-- wp:heading -->
<h2 class="wp-block-heading">Common questions</h2>
<!-- /wp:heading --><!-- wp:group {"className":"faq","layout":{"type":"default"}} -->
<div class="wp-block-group faq"><!-- wp:details -->
<details class="wp-block-details"><summary>How do I sign up?</summary><!-- wp:paragraph -->
<p>Call us. We’ll ask a few questions about your address and diet, and you can start the next Friday.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Can I sign up a parent or neighbor?</summary><!-- wp:paragraph -->
<p>Yes, with their permission. We’ll call them to confirm.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:group {"className":"box box-glow fact","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group box box-glow fact"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#truck"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph -->
<p><strong>160</strong>seniors get a delivery every week</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"box box-brand","layout":{"type":"default"}} -->
<div class="wp-block-group box box-brand"><!-- wp:heading -->
<h2 class="wp-block-heading">Keep it going</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>This program runs on gifts from neighbors. $25 provides 75 meals.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-donate"} -->
<div class="wp-block-button is-donate"><a class="wp-block-button__link wp-element-button" href="/donate/">Donate</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --><!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Questions?</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Call us on weekdays, 9 a.m. to 5 p.m.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:+15035550187">(503) 555-0187</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"lantern/cta"} /-->
