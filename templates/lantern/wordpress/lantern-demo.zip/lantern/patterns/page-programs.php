<?php
/**
 * Title: Programs page
 * Slug: lantern/page-programs
 * Categories: lantern-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Programs</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Free food, four ways</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Every program is free, open to all and run by neighbors. Find the one that fits you, or the one you’d like to help.</p>
<!-- /wp:paragraph --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1180px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:heading {"className":"screen-reader-text"} -->
<h2 class="wp-block-heading screen-reader-text">All programs</h2>
<!-- /wp:heading --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"15rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"card program","layout":{"type":"default"}} -->
<div class="wp-block-group card program"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"program-photo"} -->
<figure class="wp-block-image size-large program-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/pantry.jpg' ) ); ?>" alt="Shelves of fresh produce and groceries at a community pantry"/></figure>
<!-- /wp:image --><!-- wp:group {"className":"program-body","layout":{"type":"default"}} -->
<div class="wp-block-group program-body"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Food pantry</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Free groceries every week. Choose what your family needs, like a small grocery store.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/programs/food-pantry/">Learn more →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"card program","layout":{"type":"default"}} -->
<div class="wp-block-group card program"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"program-photo"} -->
<figure class="wp-block-image size-large program-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/meals.jpg' ) ); ?>" alt="Volunteers serving a hot meal at long shared tables"/></figure>
<!-- /wp:image --><!-- wp:group {"className":"program-body","layout":{"type":"default"}} -->
<div class="wp-block-group program-body"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Community meals</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>A hot dinner every Wednesday, open to everyone. Come hungry, stay for the company.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/programs/community-meals/">Learn more →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"card program","layout":{"type":"default"}} -->
<div class="wp-block-group card program"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"program-photo"} -->
<figure class="wp-block-image size-large program-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/kids.jpg' ) ); ?>" alt="Children eating lunch together at an outdoor picnic table"/></figure>
<!-- /wp:image --><!-- wp:group {"className":"program-body","layout":{"type":"default"}} -->
<div class="wp-block-group program-body"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Summer lunches for kids</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Free lunches at parks and libraries when school is out. Any child 18 or under can eat.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/programs/summer-lunches/">Learn more →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"card program","layout":{"type":"default"}} -->
<div class="wp-block-group card program"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"program-photo"} -->
<figure class="wp-block-image size-large program-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/delivery.jpg' ) ); ?>" alt="A volunteer carrying a box of groceries to a front door"/></figure>
<!-- /wp:image --><!-- wp:group {"className":"program-body","layout":{"type":"default"}} -->
<div class="wp-block-group program-body"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Grocery delivery for seniors</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Weekly groceries brought to the door for neighbors who can’t easily get out.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"card-link"} -->
<p class="card-link"><a href="/programs/senior-delivery/">Learn more →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"lantern/how-we-work"} /--><!-- wp:pattern {"slug":"lantern/cta"} /-->
