<?php
/**
 * Lantern's icons (original line icons by K&A Digital Studio), printed once per page.
 *
 * @package Lantern
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">
  <symbol id="lantern" viewBox="0 0 24 24"><path d="M9.5 4.5h5M12 2.5v2M7 7.5h10M8 7.5l1 11h6l1-11M7.5 18.5h9"/><path d="M12 10.5c-1.1 1.4-1.6 2.4-1.6 3.3a1.6 1.6 0 0 0 3.2 0c0-.9-.5-1.9-1.6-3.3z"/></symbol>
  <symbol id="heart" viewBox="0 0 24 24"><path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.4 4.3 4.3 0 0 1 19.5 10c0 5.4-7.5 10-7.5 10z"/></symbol>
  <symbol id="give" viewBox="0 0 24 24"><path d="M3.5 13.5h3.2l3.8 2.5h3.2a1.5 1.5 0 0 1 0 3H9.5"/><path d="M13.7 19h3.3l3.5-3.2a1.4 1.4 0 0 0-2-2L16 16"/><path d="M14 10.5s-3.2-2-3.2-4.4A1.8 1.8 0 0 1 14 5a1.8 1.8 0 0 1 3.2 1.1c0 2.4-3.2 4.4-3.2 4.4z"/></symbol>
  <symbol id="users" viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.2"/><path d="M3.5 19.5a5.5 5.5 0 0 1 11 0"/><path d="M15.5 5.2a3 3 0 0 1 0 5.6M17.5 14.3a5.3 5.3 0 0 1 3 5.2"/></symbol>
  <symbol id="basket" viewBox="0 0 24 24"><path d="M3.5 10h17l-1.8 9a1.5 1.5 0 0 1-1.5 1.2H6.8A1.5 1.5 0 0 1 5.3 19z"/><path d="m8 10 3-6M16 10l-3-6M9 13.5v3.5M12 13.5v3.5M15 13.5v3.5"/></symbol>
  <symbol id="bowl" viewBox="0 0 24 24"><path d="M3.5 11.5h17a8.5 8.5 0 0 1-17 0z"/><path d="M8.5 20.5h7"/><path d="M9 3.5c-1 1.2 1 2.3 0 3.5M12.5 3.5c-1 1.2 1 2.3 0 3.5M16 3.5c-1 1.2 1 2.3 0 3.5"/></symbol>
  <symbol id="apple" viewBox="0 0 24 24"><path d="M12 8c-1.5-1-5.5-1.2-6.5 2.5-.9 3.4 1.5 9.5 4.3 9.5 1 0 1.4-.5 2.2-.5s1.2.5 2.2.5c2.8 0 5.2-6.1 4.3-9.5C17.5 6.8 13.5 7 12 8z"/><path d="M12 8c0-2 1-3.5 3-4"/></symbol>
  <symbol id="truck" viewBox="0 0 24 24"><path d="M3 6.5h11v10H3zM14 10h3.8l3.2 3.4v3.1h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17.5" cy="17.5" r="1.8"/></symbol>
  <symbol id="sprout" viewBox="0 0 24 24"><path d="M12 20.5V12"/><path d="M12 12c0-4 3-7 8-7 0 4.5-3 7-8 7z"/><path d="M12 14.5c0-3-2.5-5.5-7-5.5 0 3.5 2.5 5.5 7 5.5z"/></symbol>
  <symbol id="house" viewBox="0 0 24 24"><path d="M4 11 12 4l8 7v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z"/></symbol>
  <symbol id="gift" viewBox="0 0 24 24"><rect x="4" y="9" width="16" height="11" rx="1.5"/><path d="M3 9h18M12 9v11"/><path d="M12 9c-1.5-3-5-4-5.5-2S9 9 12 9zm0 0c1.5-3 5-4 5.5-2S15 9 12 9z"/></symbol>
  <symbol id="repeat" viewBox="0 0 24 24"><path d="M4.5 12a7 7 0 0 1 12-5l1.5 1.5"/><path d="M18 4v4.5h-4.5"/><path d="M19.5 12a7 7 0 0 1-12 5L6 15.5"/><path d="M6 20v-4.5h4.5"/></symbol>
  <symbol id="building" viewBox="0 0 24 24"><path d="M5.5 20V5.5a1 1 0 0 1 1-1h7.5a1 1 0 0 1 1 1V20M15 10h3a1 1 0 0 1 1 1v9M3.5 20h17"/><path d="M8.5 8h3M8.5 11.5h3M8.5 15h3"/></symbol>
  <symbol id="report" viewBox="0 0 24 24"><path d="M7 3.5h7l4 4V20a.5.5 0 0 1-.5.5h-10.5a.5.5 0 0 1-.5-.5V4a.5.5 0 0 1 .5-.5z"/><path d="M14 3.5V8h4"/><path d="M12 11v6M9.5 14.5 12 17l2.5-2.5"/></symbol>
  <symbol id="chat" viewBox="0 0 24 24"><path d="M4 5h16v10.5H9.5L5 19.5v-4H4z"/><path d="M8 9h8M8 12h5"/></symbol>
  <symbol id="shield" viewBox="0 0 24 24"><path d="M12 3 4.5 6v5.5c0 4.7 3.2 8.4 7.5 9.5 4.3-1.1 7.5-4.8 7.5-9.5V6z"/><path d="m8.8 12 2.3 2.3 4.2-4.6"/></symbol>
  <symbol id="phone" viewBox="0 0 24 24"><path d="M5.5 3.5h3l1.8 4.6-2.4 1.5a11.5 11.5 0 0 0 6.5 6.5l1.5-2.4 4.6 1.8v3a2 2 0 0 1-2 2A16.5 16.5 0 0 1 3.5 5.5a2 2 0 0 1 2-2z"/></symbol>
  <symbol id="mail" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></symbol>
  <symbol id="pin" viewBox="0 0 24 24"><path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/></symbol>
  <symbol id="calendar" viewBox="0 0 24 24"><rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 10h16"/></symbol>
  <symbol id="clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></symbol>
  <symbol id="check" viewBox="0 0 24 24"><path d="m5 12.5 4.5 4.5L19 7.5"/></symbol>
  <symbol id="arrow" viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></symbol>
  <symbol id="plus" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></symbol>
  <symbol id="chevron" viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"/></symbol>
  <symbol id="menu" viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></symbol>
  <symbol id="sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M4.6 4.6 6 6M18 18l1.4 1.4M2.5 12h2M19.5 12h2M4.6 19.4 6 18M18 6l1.4-1.4"/></symbol>
  <symbol id="moon" viewBox="0 0 24 24"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></symbol>
</svg>
