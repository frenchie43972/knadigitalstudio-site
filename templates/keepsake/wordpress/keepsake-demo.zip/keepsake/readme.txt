=== Keepsake ===
Contributors: kandadigitalstudio
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 8.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A fast, elegant wedding website theme: schedule, travel, registry, FAQ, photos and an RSVP page, in three styles with light and dark mode.

== Description ==

Keepsake is a block theme for couples who want their own wedding website. Everything guests ask is in one place, and the site can stay online afterwards as a keepsake of the day.

* Home page with your names, the date, a countdown and an arched photo
* The day: a timeline schedule, the venue with directions, dress code, accessibility and rain plans
* Add-to-calendar links (Google Calendar and Apple / Outlook) for each event of the weekend
* Travel and stay: hotel blocks with booking codes and deadlines, getting here, things to do nearby
* Our story, wedding party, registry, FAQ and a photo gallery that opens photos larger
* An RSVP page ready for a free form plugin (WPForms Lite, Fluent Forms, Contact Form 7) or a Google Forms link
* 33 patterns (ready-made sections and pages) under "Keepsake sections" and "Keepsake pages"
* Three styles (Classic, Modern, Garden), each with light and dark mode
* Light/dark follows each visitor's device, with a toggle; lock it under Appearance → Keepsake options
* No page builder and no required plugins

Full setup guide: see the docs included with your download.

== Installation ==

1. In WordPress, go to Appearance → Themes → Add New Theme → Upload Theme.
2. Choose the theme zip from the K&A download (the file whose name starts with "UPLOAD THIS") and click Install Now, then Activate.
3. Optional: import demo-content.xml (Tools → Import → WordPress) to get the demo pages.

== Frequently Asked Questions ==

= How do I change the main color? =

Appearance → Editor → Styles → Colors → Brand.

= How do I switch between Classic, Modern and Garden? =

Appearance → Editor → Styles, then pick a style.

= How do I keep the site always light or always dark? =

Appearance → Keepsake options.

= How do I keep my wedding site private? =

Settings → Reading → "Discourage search engines from indexing this site". To ask guests for a password, edit a page and set Visibility to "Password protected". The setup guide covers both.

== Changelog ==

= 1.0.0 =
* First release.

== Copyright ==

Keepsake WordPress Theme, Copyright 2026 K&A Digital Studio.
Keepsake is distributed under the terms of the GNU GPL v2 or later.

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

Keepsake bundles the following resources:

Cormorant Garamond font, Copyright 2015 The Cormorant Project Authors (github.com/CatharsisFonts/Cormorant).
License: SIL Open Font License, 1.1, https://openfontlicense.org. Source: Fontsource (@fontsource/cormorant-garamond). See assets/fonts/OFL.txt.

Icons: original icons by K&A Digital Studio, GPLv2 or later.
Placeholder images and calendar files: created by K&A Digital Studio, GPLv2 or later.
