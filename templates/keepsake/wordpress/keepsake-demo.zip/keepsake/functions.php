<?php
/**
 * Keepsake theme functions.
 *
 * @package Keepsake
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'KEEPSAKE_VERSION', '1.0.0' );

/**
 * Theme setup: editor styles and translations.
 */
function keepsake_setup() {
	// The editor shows pages in a frame that can't see the icon set on the admin page,
	// so it gets the icons from a stylesheet instead; otherwise they look blank while editing.
	add_editor_style( array( 'style.css', 'assets/css/editor-icons.css' ) );
	load_theme_textdomain( 'keepsake', get_template_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'keepsake_setup' );

/**
 * Front-end styles and the small script for the light/dark toggle and the countdown.
 */
function keepsake_enqueue() {
	wp_enqueue_style( 'keepsake', get_stylesheet_uri(), array(), KEEPSAKE_VERSION );
	wp_enqueue_script(
		'keepsake',
		get_theme_file_uri( 'assets/js/keepsake.js' ),
		array(),
		KEEPSAKE_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
}
add_action( 'wp_enqueue_scripts', 'keepsake_enqueue' );

/**
 * The owner's color mode setting: "auto" (follow each visitor), "light" or "dark".
 *
 * @return string
 */
function keepsake_color_mode() {
	$mode = get_option( 'keepsake_color_mode', 'auto' );
	return in_array( $mode, array( 'auto', 'light', 'dark' ), true ) ? $mode : 'auto';
}

/**
 * When the owner locks a mode, mark it on <html> so styles and the toggle follow it.
 *
 * @param string $output Attributes for the html tag.
 * @return string
 */
function keepsake_html_attributes( $output ) {
	$mode = keepsake_color_mode();
	if ( 'auto' !== $mode ) {
		$output .= ' data-mode="' . esc_attr( $mode ) . '" data-mode-lock="' . esc_attr( $mode ) . '"';
	}
	return $output;
}
add_filter( 'language_attributes', 'keepsake_html_attributes' );

/**
 * Apply a visitor's saved light/dark choice before the page draws, so it never flashes.
 */
function keepsake_mode_head_script() {
	if ( 'auto' !== keepsake_color_mode() ) {
		return;
	}
	wp_print_inline_script_tag( 'try{var m=localStorage.getItem("keepsake-mode");if(m==="light"||m==="dark")document.documentElement.setAttribute("data-mode",m)}catch(e){}' );
}
add_action( 'wp_head', 'keepsake_mode_head_script', 1 );

/**
 * Load the hero photo first and the other photos as they scroll into view. WordPress only does
 * this by itself for images it knows the size of, and Keepsake's photos start as theme images.
 * The hero's "is-hero" class stays on the block when the photo is replaced.
 *
 * @param string $block_content Rendered image block.
 * @param array  $block         Block data.
 * @return string
 */
function keepsake_hero_image_priority( $block_content, $block ) {
	$is_hero = ! empty( $block['attrs']['className'] ) && false !== strpos( $block['attrs']['className'], 'is-hero' );
	$tags    = new WP_HTML_Tag_Processor( $block_content );
	if ( ! $tags->next_tag( 'img' ) ) {
		return $block_content;
	}
	if ( $is_hero ) {
		$tags->set_attribute( 'fetchpriority', 'high' );
		$tags->remove_attribute( 'loading' );
	} elseif ( null === $tags->get_attribute( 'loading' ) && null === $tags->get_attribute( 'fetchpriority' ) ) {
		$tags->set_attribute( 'loading', 'lazy' );
		$tags->set_attribute( 'decoding', 'async' );
	}
	return $tags->get_updated_html();
}
add_filter( 'render_block_core/image', 'keepsake_hero_image_priority', 10, 2 );

/**
 * Print Keepsake's icon set once per page (patterns reference the icons by name).
 */
function keepsake_print_icons() {
	require get_theme_file_path( 'assets/icons.php' );
}
add_action( 'wp_footer', 'keepsake_print_icons' );
add_action( 'admin_footer', 'keepsake_print_icons' );

/**
 * Pattern categories shown in the editor.
 */
function keepsake_pattern_categories() {
	register_block_pattern_category( 'keepsake', array( 'label' => __( 'Keepsake sections', 'keepsake' ) ) );
	register_block_pattern_category( 'keepsake-pages', array( 'label' => __( 'Keepsake pages', 'keepsake' ) ) );
}
add_action( 'init', 'keepsake_pattern_categories' );

/**
 * Appearance → Keepsake options: one setting for the color mode.
 */
function keepsake_options_menu() {
	add_theme_page( __( 'Keepsake options', 'keepsake' ), __( 'Keepsake options', 'keepsake' ), 'edit_theme_options', 'keepsake-options', 'keepsake_options_page' );
}
add_action( 'admin_menu', 'keepsake_options_menu' );

/**
 * Register the color mode setting.
 */
function keepsake_register_settings() {
	register_setting(
		'keepsake_options',
		'keepsake_color_mode',
		array(
			'type'              => 'string',
			'default'           => 'auto',
			'sanitize_callback' => 'keepsake_sanitize_mode',
		)
	);
}
add_action( 'admin_init', 'keepsake_register_settings' );

/**
 * Only accept the three known modes.
 *
 * @param string $value Submitted value.
 * @return string
 */
function keepsake_sanitize_mode( $value ) {
	return in_array( $value, array( 'auto', 'light', 'dark' ), true ) ? $value : 'auto';
}

/**
 * The options screen.
 */
function keepsake_options_page() {
	$mode    = keepsake_color_mode();
	$choices = array(
		'auto'  => __( 'Follow each visitor (their device setting, plus a light/dark button in the header)', 'keepsake' ),
		'light' => __( 'Always light (hides the light/dark button)', 'keepsake' ),
		'dark'  => __( 'Always dark (hides the light/dark button)', 'keepsake' ),
	);
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Keepsake options', 'keepsake' ); ?></h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'keepsake_options' ); ?>
			<h2><?php esc_html_e( 'Light and dark mode', 'keepsake' ); ?></h2>
			<fieldset>
				<?php foreach ( $choices as $value => $label ) : ?>
					<p><label><input type="radio" name="keepsake_color_mode" value="<?php echo esc_attr( $value ); ?>" <?php checked( $mode, $value ); ?>> <?php echo esc_html( $label ); ?></label></p>
				<?php endforeach; ?>
			</fieldset>
			<p><?php esc_html_e( 'Colors, fonts and the Classic, Modern or Garden style are set under Appearance → Editor → Styles.', 'keepsake' ); ?></p>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/**
 * A meta description for search results, unless an SEO plugin already writes one.
 * Uses the page's excerpt when it has one, otherwise the site tagline.
 */
function keepsake_meta_description() {
	if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || class_exists( 'The_SEO_Framework\Load' ) ) {
		return;
	}
	$description = '';
	if ( is_singular() && has_excerpt() ) {
		$description = get_the_excerpt();
	}
	if ( '' === $description ) {
		$description = get_bloginfo( 'description' );
	}
	if ( '' !== $description ) {
		printf( '<meta name="description" content="%s">' . "\n", esc_attr( wp_strip_all_tags( $description ) ) );
	}
}
add_action( 'wp_head', 'keepsake_meta_description', 2 );
