<?php
/**
 * Title: RSVP call to action
 * Slug: keepsake/rsvp-band
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-tight","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section is-tight"><!-- wp:group {"className":"rsvp-band","layout":{"type":"default"}} -->
<div class="wp-block-group rsvp-band"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Will you join us?</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Kindly reply by May 1, 2027</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>It takes a minute, and it helps us plan the food, the chairs and the dance floor.</p>
<!-- /wp:paragraph --><!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/rsvp/">RSVP now</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
