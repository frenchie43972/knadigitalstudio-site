<?php
/**
 * Title: Photo gallery
 * Slug: keepsake/gallery
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:gallery {"columns":3,"linkTo":"none","className":"keepsake-gallery"} -->
<figure class="wp-block-gallery has-nested-images columns-3 is-cropped keepsake-gallery">
<!-- wp:image {"lightbox":{"enabled":true},"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/gallery-1.jpg' ) ); ?>" alt="The couple embracing among green leaves"/></figure>
<!-- /wp:image -->
<!-- wp:image {"lightbox":{"enabled":true},"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/gallery-2.jpg' ) ); ?>" alt="Rows of chairs on the lawn facing a flower arch"/></figure>
<!-- /wp:image -->
<!-- wp:image {"lightbox":{"enabled":true},"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/gallery-3.jpg' ) ); ?>" alt="Two gold wedding rings on cream fabric"/></figure>
<!-- /wp:image -->
<!-- wp:image {"lightbox":{"enabled":true},"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/gallery-4.jpg' ) ); ?>" alt="A white and green bouquet"/></figure>
<!-- /wp:image -->
<!-- wp:image {"lightbox":{"enabled":true},"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/gallery-5.jpg' ) ); ?>" alt="Round tables with flowers under a white tent"/></figure>
<!-- /wp:image -->
<!-- wp:image {"lightbox":{"enabled":true},"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/gallery-6.jpg' ) ); ?>" alt="The first dance under falling confetti"/></figure>
<!-- /wp:image -->
<!-- wp:image {"lightbox":{"enabled":true},"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/gallery-7.jpg' ) ); ?>" alt="A white wedding cake with berries and flowers"/></figure>
<!-- /wp:image -->
<!-- wp:image {"lightbox":{"enabled":true},"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/gallery-8.jpg' ) ); ?>" alt="Guests dancing on the grass with the couple"/></figure>
<!-- /wp:image --></figure>
<!-- /wp:gallery --></section>
<!-- /wp:group -->
