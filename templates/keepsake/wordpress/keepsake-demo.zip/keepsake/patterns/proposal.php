<?php
/**
 * Title: The proposal
 * Slug: keepsake/proposal
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"keepsake-photo"} -->
<figure class="wp-block-image size-large keepsake-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/story.jpg' ) ); ?>" alt="Sam giving Elena a piggyback ride, both laughing"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">The proposal</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">A windy evening at Lighthouse Point</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">Sam had planned a speech. The wind had other plans. In the end it was four words, a ring that nearly blew away, and a very loud yes.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">We can’t wait to celebrate the next chapter with you.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/rsvp/">RSVP</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
