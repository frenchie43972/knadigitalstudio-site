<?php
/**
 * Title: RSVP page
 * Slug: keepsake/page-rsvp
 * Categories: keepsake-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:html -->
<div class="ornament" aria-hidden="true"><svg class="icon" aria-hidden="true"><use href="#sprig"></use></svg></div>
<!-- /wp:html --><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">RSVP</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Will you join us?</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Please reply by May 1, 2027, one form per invitation. If your plans change, just email us.</p>
<!-- /wp:paragraph --></section>
<!-- /wp:group --><!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"top"} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top","width":"64%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:64%"><!-- wp:pattern {"slug":"keepsake/rsvp-form-slot"} /--></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:pattern {"slug":"keepsake/rsvp-aside"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
