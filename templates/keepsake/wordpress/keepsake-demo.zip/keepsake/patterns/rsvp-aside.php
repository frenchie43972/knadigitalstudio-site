<?php
/**
 * Title: RSVP deadline and questions
 * Slug: keepsake/rsvp-aside
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"className":"aside-stack","layout":{"type":"default"}} -->
<div class="wp-block-group aside-stack"><!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Reply by May 1, 2027</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>After that we give the final numbers to the caterer. Changes are fine; just email us.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">What happens next</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>You’ll see a thank-you page right away. In May we’ll send a short email with the final details and the shuttle times.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Questions?</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"line-mail"} -->
<p class="line-mail"><a href="mailto:hello@example.com">hello@example.com</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
