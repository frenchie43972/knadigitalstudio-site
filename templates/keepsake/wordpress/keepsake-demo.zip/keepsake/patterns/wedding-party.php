<?php
/**
 * Title: Wedding party
 * Slug: keepsake/wedding-party
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:heading {"className":"party-side"} -->
<h2 class="wp-block-heading party-side">Elena’s side</h2>
<!-- /wp:heading --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"20rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">PS</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Priya Shah</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"role"} -->
<p class="role">Maid of honor</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>College roommate, keeper of every secret and the reason Elena owns a raincoat.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">LM</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Lucia Moreno</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"role"} -->
<p class="role">Bridesmaid</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Elena’s little sister, who has been planning this wedding since she was nine.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">HL</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Hannah Lee</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"role"} -->
<p class="role">Bridesmaid</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Book club founder. Technically, this is all her fault.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:heading {"className":"party-side"} -->
<h2 class="wp-block-heading party-side">Sam’s side</h2>
<!-- /wp:heading --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"20rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">MB</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Marcus Bell</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"role"} -->
<p class="role">Best man</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Sam’s brother, co-pilot of the broken-radio road trip and owner of the best laugh in the family.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">TO</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Tom Okafor</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"role"} -->
<p class="role">Groomsman</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Friends with Sam since they were six, when they built a raft that sank in four seconds.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">OP</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Owen Park</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"role"} -->
<p class="role">Groomsman</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Running partner, cooking partner and the calmest person we know.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
