<?php
/**
 * Title: Accessibility, weather and photos
 * Slug: keepsake/good-to-know
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"20rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"way","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group way"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#access"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Accessibility</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>The barn and restrooms are step-free, and a golf cart can drive anyone to the meadow. Tell us what you need on the RSVP form.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"way","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group way"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#umbrella"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">If it rains</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>The ceremony moves into the barn. We’ll post an update here on the morning of the wedding.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"way","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group way"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#camera"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">An unplugged ceremony</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Phones away for the vows, please. After that, share everything with #ElenaAndSam.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
