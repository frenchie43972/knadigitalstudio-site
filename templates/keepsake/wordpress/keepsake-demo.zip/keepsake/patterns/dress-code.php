<?php
/**
 * Title: Dress code
 * Slug: keepsake/dress-code
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"top"} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top","width":"55%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:55%"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">What to wear</p>
<!-- /wp:paragraph --><!-- wp:heading {"anchor":"dress"} -->
<h2 id="dress" class="wp-block-heading">Garden formal</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Garden formal: think suits or a jacket and slacks, summer dresses, jumpsuits. Ties optional. The ceremony is on grass, so leave the stilettos at home and bring block heels or flats. Evenings by the coast get cool, so pack a layer.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Good to know</h3>
<!-- /wp:heading --><!-- wp:list {"className":"checklist"} -->
<ul class="wp-block-list checklist">
<!-- wp:list-item -->
<li>Block heels, flats or boots for the grass</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>A light jacket or wrap for the evening</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Sunglasses: the ceremony faces west</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Any color you like, except all-white</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
