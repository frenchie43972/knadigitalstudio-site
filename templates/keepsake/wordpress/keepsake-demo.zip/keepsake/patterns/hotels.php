<?php
/**
 * Title: Hotel blocks
 * Slug: keepsake/hotels
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"section-head","layout":{"type":"default"}} -->
<div class="wp-block-group section-head"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Travel &amp; stay</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Make a weekend of it</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">We’ve held rooms at three places nearby. Book early: June on the coast fills up fast.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"20rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:paragraph {"className":"tag"} -->
<p class="tag">10 minutes from the farm</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">The Bayside Inn</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Our main hotel, with a free shuttle to and from the farm on Saturday.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"price"} -->
<p class="price">From $189 a night</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"code"} -->
<p class="code">Book online with code <strong>ELENASAM</strong>, or call and ask for the Elena &amp; Sam wedding rate.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"deadline"} -->
<p class="deadline">Book by May 12, 2027</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:paragraph {"className":"tag"} -->
<p class="tag">15 minutes from the farm</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Harborview Hotel</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>On the water in town, a short walk to the welcome drinks.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"price"} -->
<p class="price">From $159 a night</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"code"} -->
<p class="code">Call the hotel and mention the Elena &amp; Sam wedding.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"deadline"} -->
<p class="deadline">Book by May 1, 2027</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:paragraph {"className":"tag"} -->
<p class="tag">On the farm</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Mill Pond Cottages</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Four cottages on the farm itself. Walk to the ceremony, roll home after the last dance.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"price"} -->
<p class="price">From $240 a night</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"code"} -->
<p class="code">Email us and we’ll put you in touch with the farm. First come, first served.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"deadline"} -->
<p class="deadline">Ask by April 1, 2027</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:paragraph {"className":"more-link"} -->
<p class="more-link"><a href="/travel/">Getting here and things to do →</a></p>
<!-- /wp:paragraph --></section>
<!-- /wp:group -->
