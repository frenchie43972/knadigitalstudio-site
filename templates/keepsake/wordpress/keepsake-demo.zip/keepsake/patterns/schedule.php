<?php
/**
 * Title: Schedule of the day
 * Slug: keepsake/schedule
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"section-head","layout":{"type":"default"}} -->
<div class="wp-block-group section-head"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Saturday</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">The schedule</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"className":"schedule","layout":{"type":"default"}} -->
<div class="wp-block-group schedule"><!-- wp:group {"className":"schedule-item","layout":{"type":"default"}} -->
<div class="wp-block-group schedule-item"><!-- wp:paragraph {"className":"time"} -->
<p class="time">3:30 pm</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"slot","layout":{"type":"default"}} -->
<div class="wp-block-group slot"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Guests arrive</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"where"} -->
<p class="where">Parking field</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Park in the field by the gate and follow the lanterns down to the meadow.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"schedule-item","layout":{"type":"default"}} -->
<div class="wp-block-group schedule-item"><!-- wp:paragraph {"className":"time"} -->
<p class="time">4:00 pm</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"slot","layout":{"type":"default"}} -->
<div class="wp-block-group slot"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Ceremony</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"where"} -->
<p class="where">The meadow</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>A short ceremony under the old oak. Please be seated by 3:50.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"schedule-item","layout":{"type":"default"}} -->
<div class="wp-block-group schedule-item"><!-- wp:paragraph {"className":"time"} -->
<p class="time">4:45 pm</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"slot","layout":{"type":"default"}} -->
<div class="wp-block-group slot"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Cocktail hour</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"where"} -->
<p class="where">The lawn</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Drinks, snacks and lawn games while we take a few photos.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"schedule-item","layout":{"type":"default"}} -->
<div class="wp-block-group schedule-item"><!-- wp:paragraph {"className":"time"} -->
<p class="time">6:00 pm</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"slot","layout":{"type":"default"}} -->
<div class="wp-block-group slot"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Dinner</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"where"} -->
<p class="where">The barn</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>A family-style dinner with toasts from the people who know us best.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"schedule-item","layout":{"type":"default"}} -->
<div class="wp-block-group schedule-item"><!-- wp:paragraph {"className":"time"} -->
<p class="time">8:00 pm</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"slot","layout":{"type":"default"}} -->
<div class="wp-block-group slot"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Dancing</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"where"} -->
<p class="where">The barn</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>First dance, then the floor is yours. Requests welcome.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"schedule-item","layout":{"type":"default"}} -->
<div class="wp-block-group schedule-item"><!-- wp:paragraph {"className":"time"} -->
<p class="time">11:00 pm</p>
<!-- /wp:paragraph --><!-- wp:group {"className":"slot","layout":{"type":"default"}} -->
<div class="wp-block-group slot"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Send-off</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"where"} -->
<p class="where">The lane</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Help us end the night with sparklers on the lane. Shuttles leave from the gate.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
