<?php
/**
 * Title: RSVP thank-you page
 * Slug: keepsake/page-thank-you
 * Categories: keepsake-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"className":"center-page","layout":{"type":"default"}} -->
<div class="wp-block-group center-page"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#heart"></use></svg></span>
<!-- /wp:html --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Thank you!</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">We’ve got your reply. If you said yes, we can’t wait to see you on June 12, 2027. If you can’t make it, we’ll miss you, and we’ll raise a glass to you.</p>
<!-- /wp:paragraph --><!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/the-day/">See the schedule</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/travel/">Find a place to stay</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
