<?php
/**
 * Title: Getting here
 * Slug: keepsake/getting-here
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:group {"className":"section-head","layout":{"type":"default"}} -->
<div class="wp-block-group section-head"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Getting here</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">By plane, car or shuttle</h2>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"20rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"way","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group way"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#plane"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">By plane</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Fly into Portland (PDX). Bayside is about 90 minutes’ drive west. If you’re renting a car, book early: June is busy.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"way","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group way"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#car"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">By car</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Mill Pond Farm is 4 miles east of Bayside on Mill Pond Road. Free parking in the field by the gate; the last mile is gravel.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"way","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group way"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#bus"></use></svg></span>
<!-- /wp:html --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Shuttle</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>A shuttle runs from The Bayside Inn to the farm from 3:00 pm, and back every hour from 9:00 pm until the end of the night.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
