<?php
/**
 * Title: Registry page
 * Slug: keepsake/page-registry
 * Categories: keepsake-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:html -->
<div class="ornament" aria-hidden="true"><svg class="icon" aria-hidden="true"><use href="#sprig"></use></svg></div>
<!-- /wp:html --><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Registry</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Your being there is the gift</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Your being there is the best gift. Truly. If you’d like to give something, here are a few ideas.</p>
<!-- /wp:paragraph --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"keepsake/registry"} /--><!-- wp:pattern {"slug":"keepsake/gift-note"} /-->
