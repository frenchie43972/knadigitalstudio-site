<?php
/**
 * Title: A note on gifts
 * Slug: keepsake/gift-note
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:group {"className":"welcome","layout":{"type":"default"}} -->
<div class="wp-block-group welcome"><!-- wp:html -->
<div class="ornament" aria-hidden="true"><svg class="icon" aria-hidden="true"><use href="#sprig"></use></svg></div>
<!-- /wp:html --><!-- wp:paragraph {"className":"welcome-text"} -->
<p class="welcome-text">Bringing a gift on the day? There’ll be a card box at the welcome table. For anything bigger, we’d love it sent to our home instead, so nothing gets lost.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"signature"} -->
<p class="signature">Thank you, truly</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
