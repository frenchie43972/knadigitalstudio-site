<?php
/**
 * Title: Hero: names, date and arched photo
 * Slug: keepsake/hero
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section hero","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section hero"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center","width":"55%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:55%"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">We’re getting married</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1,"className":"names"} -->
<h1 class="wp-block-heading names">Elena<br><em>&amp;</em><br>Sam</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"when"} -->
<p class="when"><strong>Saturday, June 12, 2027</strong><br>Mill Pond Farm · Bayside, Oregon</p>
<!-- /wp:paragraph --><!-- wp:html -->
<!-- Countdown: data-date is your ceremony time with your time zone offset. After the day, the data-after text shows instead. -->
<p class="countdown" data-countdown data-date="2027-06-12T16:00:00-07:00" data-after="Married June 12, 2027. Thank you for celebrating with us.">Counting down to June 12, 2027</p>
<!-- /wp:html --><!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/rsvp/">RSVP by May 1</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/the-day/">See the schedule</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"arch is-hero"} -->
<figure class="wp-block-image size-large arch is-hero"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/hero.jpg' ) ); ?>" alt="Elena &amp; Sam walking hand in hand through a summer field"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
