<?php
/**
 * Title: Our story teaser
 * Slug: keepsake/story-teaser
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"keepsake-photo"} -->
<figure class="wp-block-image size-large keepsake-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/story.jpg' ) ); ?>" alt="Sam giving Elena a piggyback ride, both laughing"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Our story</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">It started with a book neither of us read</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">We met in 2019 at a book club neither of us had read the book for. Seven years, one dog and a lot of bad singing later, we’re getting married, and we’d love you there.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/our-story/">Read our story</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
