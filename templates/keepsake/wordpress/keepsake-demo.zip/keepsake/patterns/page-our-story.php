<?php
/**
 * Title: Our story page
 * Slug: keepsake/page-our-story
 * Categories: keepsake-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:html -->
<div class="ornament" aria-hidden="true"><svg class="icon" aria-hidden="true"><use href="#sprig"></use></svg></div>
<!-- /wp:html --><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Our story</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">How we got here</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">We met in 2019 at a book club neither of us had read the book for. Seven years, one dog and a lot of bad singing later, we’re getting married, and we’d love you there.</p>
<!-- /wp:paragraph --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"keepsake/story-timeline"} /--><!-- wp:pattern {"slug":"keepsake/proposal"} /-->
