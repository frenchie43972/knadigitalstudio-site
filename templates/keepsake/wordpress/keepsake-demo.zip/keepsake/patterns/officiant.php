<?php
/**
 * Title: Officiant and ring bearer
 * Slug: keepsake/officiant
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:heading {"className":"party-side"} -->
<h2 class="wp-block-heading party-side">And also</h2>
<!-- /wp:heading --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"26rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">RA</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Ruth Abernathy</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"role"} -->
<p class="role">Officiant</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Sam’s aunt, who has been waiting to say “I told you so” since 2019.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"member","layout":{"type":"default"}} -->
<div class="wp-block-group member"><!-- wp:html -->
<span class="avatar" aria-hidden="true">B</span>
<!-- /wp:html --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Biscuit</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"role"} -->
<p class="role">Ring bearer</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Very good dog. Will be on a leash. Mostly.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
