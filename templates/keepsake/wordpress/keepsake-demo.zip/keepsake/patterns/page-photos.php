<?php
/**
 * Title: Photos page
 * Slug: keepsake/page-photos
 * Categories: keepsake-pages
 * Post Types: page
 * Block Types: core/post-content
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section page-hero","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section page-hero"><!-- wp:html -->
<div class="ornament" aria-hidden="true"><svg class="icon" aria-hidden="true"><use href="#sprig"></use></svg></div>
<!-- /wp:html --><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">Photos</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">A few favorite moments</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">More to come after the wedding. Took a good one? Share it with #ElenaAndSam.</p>
<!-- /wp:paragraph --></section>
<!-- /wp:group --><!-- wp:pattern {"slug":"keepsake/gallery"} /-->
