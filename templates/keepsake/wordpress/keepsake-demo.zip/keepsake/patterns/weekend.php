<?php
/**
 * Title: The weekend at a glance
 * Slug: keepsake/weekend
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:group {"className":"section-head","layout":{"type":"default"}} -->
<div class="wp-block-group section-head"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">The weekend</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Three days, one big celebration</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Friday drinks, the wedding on Saturday and a lazy brunch on Sunday. Come to as much as you can.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"20rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"event-card","layout":{"type":"default"}} -->
<div class="wp-block-group event-card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#glasses"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"day"} -->
<p class="day">Friday, June 11</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Welcome drinks</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"meta"} -->
<p class="meta">7 pm to 9:30 pm<br><span>The Harbor House</span></p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Come say hello the night before. Drinks and small plates on the deck, casual clothes. Everyone is welcome; no need to RSVP for this one.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"cal-links"} -->
<p class="cal-links"><a href="https://calendar.google.com/calendar/render?action=TEMPLATE&amp;text=Welcome%20drinks%3A%20Elena%20%26%20Sam&amp;dates=20270611T190000%2F20270611T213000&amp;ctz=America%2FLos_Angeles&amp;location=The%20Harbor%20House%2C%2012%20Front%20Street%2C%20Bayside%2C%20OR&amp;details=Come%20say%20hello%20the%20night%20before.%20Drinks%20and%20small%20plates%20on%20the%20deck%2C%20casual%20clothes.%20Everyone%20is%20welcome%3B%20no%20need%20to%20RSVP%20for%20this%20one.">Google Calendar</a> <a href="<?php echo esc_url( get_theme_file_uri( 'assets/calendar/welcome.ics' ) ); ?>" download>Apple / Outlook</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"event-card is-main","layout":{"type":"default"}} -->
<div class="wp-block-group event-card is-main"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#rings"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"day"} -->
<p class="day">Saturday, June 12</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">The wedding</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"meta"} -->
<p class="meta">3:30 pm to 11 pm<br><span>Mill Pond Farm</span></p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Ceremony in the meadow, then cocktails on the lawn, dinner in the barn and dancing until late.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"cal-links"} -->
<p class="cal-links"><a href="https://calendar.google.com/calendar/render?action=TEMPLATE&amp;text=The%20wedding%3A%20Elena%20%26%20Sam&amp;dates=20270612T153000%2F20270612T230000&amp;ctz=America%2FLos_Angeles&amp;location=Mill%20Pond%20Farm%2C%202210%20Mill%20Pond%20Road%2C%20Bayside%2C%20OR&amp;details=Ceremony%20in%20the%20meadow%2C%20then%20cocktails%20on%20the%20lawn%2C%20dinner%20in%20the%20barn%20and%20dancing%20until%20late.">Google Calendar</a> <a href="<?php echo esc_url( get_theme_file_uri( 'assets/calendar/wedding.ics' ) ); ?>" download>Apple / Outlook</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"event-card","layout":{"type":"default"}} -->
<div class="wp-block-group event-card"><!-- wp:html -->
<span class="icon-tile"><svg class="icon" aria-hidden="true"><use href="#plate"></use></svg></span>
<!-- /wp:html --><!-- wp:paragraph {"className":"day"} -->
<p class="day">Sunday, June 13</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Farewell brunch</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"meta"} -->
<p class="meta">10 am to 12 pm<br><span>Mill Pond Farm</span></p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Pastries, coffee and one last hug before you head home. Drop in any time between 10 and noon.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"cal-links"} -->
<p class="cal-links"><a href="https://calendar.google.com/calendar/render?action=TEMPLATE&amp;text=Farewell%20brunch%3A%20Elena%20%26%20Sam&amp;dates=20270613T100000%2F20270613T120000&amp;ctz=America%2FLos_Angeles&amp;location=Mill%20Pond%20Farm%2C%202210%20Mill%20Pond%20Road%2C%20Bayside%2C%20OR&amp;details=Pastries%2C%20coffee%20and%20one%20last%20hug%20before%20you%20head%20home.%20Drop%20in%20any%20time%20between%2010%20and%20noon.">Google Calendar</a> <a href="<?php echo esc_url( get_theme_file_uri( 'assets/calendar/brunch.ics' ) ); ?>" download>Apple / Outlook</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:paragraph {"className":"more-link"} -->
<p class="more-link"><a href="/the-day/">Schedule, dress code and directions →</a></p>
<!-- /wp:paragraph --></section>
<!-- /wp:group -->
