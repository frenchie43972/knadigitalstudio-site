<?php
/**
 * Title: Welcome note
 * Slug: keepsake/welcome
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"welcome","layout":{"type":"default"}} -->
<div class="wp-block-group welcome"><!-- wp:html -->
<div class="ornament" aria-hidden="true"><svg class="icon" aria-hidden="true"><use href="#sprig"></use></svg></div>
<!-- /wp:html --><!-- wp:paragraph {"className":"welcome-text"} -->
<p class="welcome-text">We can’t wait to celebrate with the people we love most. This site has everything you need for the weekend: when and where, what to wear, where to stay and how to RSVP. If you can’t find an answer, just ask us.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"signature"} -->
<p class="signature">Love, Elena &amp; Sam</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
