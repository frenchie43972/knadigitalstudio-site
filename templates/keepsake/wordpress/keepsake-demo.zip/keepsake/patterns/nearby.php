<?php
/**
 * Title: Things to do nearby
 * Slug: keepsake/nearby
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"section-head","layout":{"type":"default"}} -->
<div class="wp-block-group section-head"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">While you’re here</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">A few of our favorite things</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Staying the weekend? These are the places we take everyone who visits.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"15rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Lighthouse Point</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Where Sam proposed. A short walk to the best sunset on the coast.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">The harbor walk</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Two easy miles along the water, with coffee and ice cream on the way.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Saturday market</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Local berries, bread and flowers, 8 am to 1 pm on Front Street.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"card","layout":{"type":"default"}} -->
<div class="wp-block-group card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Mill Pond trail</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>A gentle loop through the woods behind the farm. Bring good shoes.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
