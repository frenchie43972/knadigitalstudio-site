<?php
/**
 * Title: Our story, year by year
 * Slug: keepsake/story-timeline
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"moments","layout":{"type":"default"}} -->
<div class="wp-block-group moments"><!-- wp:group {"className":"moment","layout":{"type":"default"}} -->
<div class="wp-block-group moment"><!-- wp:paragraph {"className":"year"} -->
<p class="year">2019</p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">A rainy book club</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Elena turned up to a friend’s book club having not read the book. Sam hadn’t either. They spent the evening pretending, then laughing about it over cold pizza.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"moment","layout":{"type":"default"}} -->
<div class="wp-block-group moment"><!-- wp:paragraph {"className":"year"} -->
<p class="year">2021</p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">The first big trip</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Two weeks, one rental car with a broken radio and a lot of singing. They came home knowing they were in it for the long run.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"moment","layout":{"type":"default"}} -->
<div class="wp-block-group moment"><!-- wp:paragraph {"className":"year"} -->
<p class="year">2023</p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">A home and a Biscuit</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>They moved into a small house by the harbor and adopted Biscuit, a dog with strong opinions about mail carriers.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"moment","layout":{"type":"default"}} -->
<div class="wp-block-group moment"><!-- wp:paragraph {"className":"year"} -->
<p class="year">2026</p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">The question</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>On a windy evening at Lighthouse Point, Sam asked. Elena said yes before the question was finished. Biscuit barked twice, which we’re counting as a blessing.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
