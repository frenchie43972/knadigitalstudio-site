<?php
/**
 * Title: RSVP form spot
 * Slug: keepsake/rsvp-form-slot
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"className":"box","layout":{"type":"default"}} -->
<div class="wp-block-group box"><!-- wp:heading -->
<h2 class="wp-block-heading">Your reply</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">Add your RSVP form here. Install a free form plugin such as WPForms Lite or Fluent Forms, build the form (the setup guide lists the questions to ask), then replace this box with the form’s block. Prefer Google Forms or Tally? Replace it with a button that links to your form.</p>
<!-- /wp:paragraph --><!-- wp:html -->
<div class="embed-slot"><svg class="icon" aria-hidden="true"><use href="#rings"></use></svg><strong>Your RSVP form goes here</strong><span>See “RSVP form” in the Keepsake guide.</span></div>
<!-- /wp:html --><!-- wp:paragraph {"className":"has-soft-text has-small-font-size"} -->
<p class="has-soft-text has-small-font-size">We only use your answers to plan the wedding, and we delete them afterwards.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
