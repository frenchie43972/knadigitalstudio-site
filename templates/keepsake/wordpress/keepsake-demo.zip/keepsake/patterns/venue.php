<?php
/**
 * Title: Venue with photo and directions
 * Slug: keepsake/venue
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section is-soft","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section is-soft"><!-- wp:group {"className":"box venue-card","layout":{"type":"default"}} -->
<div class="wp-block-group box venue-card"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"venue-photo"} -->
<figure class="wp-block-image size-large venue-photo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/venue.jpg' ) ); ?>" alt="The white barn at Mill Pond Farm under a blue sky"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">The place</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Mill Pond Farm</h2>
<!-- /wp:heading --><!-- wp:paragraph {"className":"line-pin"} -->
<p class="line-pin">2210 Mill Pond Road, Bayside, OR</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"has-soft-text"} -->
<p class="has-soft-text">A family farm with a meadow for the ceremony, a big lawn and a restored barn for dinner and dancing. Free parking in the field by the gate.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="https://www.google.com/maps/search/?api=1&amp;query=2210+Mill+Pond+Road+Bayside+OR">Get directions</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
