<?php
/**
 * Title: Questions and answers
 * Slug: keepsake/faq
 * Categories: keepsake
 * Viewport Width: 1280
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- wp:group {"tagName":"section","align":"full","className":"section","layout":{"type":"constrained","contentSize":"1160px"}} -->
<section class="wp-block-group alignfull section"><!-- wp:group {"className":"faq","layout":{"type":"default"}} -->
<div class="wp-block-group faq"><!-- wp:details -->
<details class="wp-block-details"><summary>When should I RSVP by?</summary><!-- wp:paragraph -->
<p>Please RSVP by May 1, 2027, using the <a href="/rsvp/">RSVP form</a>. If something changes later, just email us.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Can I bring a guest?</summary><!-- wp:paragraph -->
<p>If your invitation says “and guest”, yes. Otherwise we’re keeping things small, and we hope you understand.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Are kids welcome?</summary><!-- wp:paragraph -->
<p>We love your kids. The ceremony and dinner are family-friendly, and there’s a kids’ meal. After 9 pm it’s a grown-ups’ party.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>What should I wear?</summary><!-- wp:paragraph -->
<p>Garden formal. The ceremony is on grass, so wear comfortable shoes, and bring a layer for the evening. See <a href="/the-day/#dress">dress code</a>.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>What if it rains?</summary><!-- wp:paragraph -->
<p>The ceremony moves into the barn, which is lovely too. We’ll post an update on this page the morning of the wedding.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Is there parking?</summary><!-- wp:paragraph -->
<p>Yes, free parking in the field by the gate. The shuttle from The Bayside Inn is the easiest way home after the party.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Can I take photos during the ceremony?</summary><!-- wp:paragraph -->
<p>We’re asking for an unplugged ceremony: phones away until we walk back down the aisle. After that, snap away and share them with #ElenaAndSam.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>I have a dietary need. Who do I tell?</summary><!-- wp:paragraph -->
<p>Tell us on the RSVP form and we’ll make sure the kitchen knows. Vegetarian, vegan and gluten-free are all easy.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>Is the venue accessible?</summary><!-- wp:paragraph -->
<p>The barn and restrooms are step-free. The meadow is a short, gently sloping grass path; we’ll have a golf cart to drive anyone who’d like a ride.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --><!-- wp:details -->
<details class="wp-block-details"><summary>What about gifts?</summary><!-- wp:paragraph -->
<p>Your presence is plenty. If you’d like to give something, see our <a href="/registry/">registry</a>.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
