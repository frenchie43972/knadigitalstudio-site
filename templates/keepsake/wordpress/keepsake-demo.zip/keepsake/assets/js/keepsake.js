// Keepsake: light/dark toggle and countdown. The visitor's light/dark choice is
// remembered; without a choice the site follows the device setting. When the owner
// locks a mode (Appearance → Keepsake options), the toggle is hidden.
(function () {
  var root = document.documentElement;
  var toggles = document.querySelectorAll(".mode-toggle");
  if (!toggles.length) return;
  if (root.hasAttribute("data-mode-lock")) {
    toggles.forEach(function (t) { t.hidden = true; });
    return;
  }
  function currentMode() {
    var set = root.getAttribute("data-mode");
    if (set) return set;
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
  function label() {
    toggles.forEach(function (t) {
      t.setAttribute("aria-label", currentMode() === "dark" ? "Switch to light mode" : "Switch to dark mode");
    });
  }
  toggles.forEach(function (t) {
    t.addEventListener("click", function () {
      var next = currentMode() === "dark" ? "light" : "dark";
      root.setAttribute("data-mode", next);
      try { localStorage.setItem("keepsake-mode", next); } catch (e) {}
      label();
    });
  });
  label();
})();

// Countdown: counts the days to the date in data-date. After the day it shows
// the text in data-after instead (for example "Married June 12, 2027").
(function () {
  document.querySelectorAll("[data-countdown]").forEach(function (el) {
    var when = new Date(el.getAttribute("data-date"));
    if (isNaN(when)) return;
    var days = Math.ceil((when - new Date()) / 86400000);
    if (days > 1) el.innerHTML = "<strong>" + days + "</strong> days to go";
    else if (days === 1) el.innerHTML = "<strong>1</strong> day to go";
    else if (days === 0) el.textContent = "Today’s the day!";
    else el.textContent = el.getAttribute("data-after") || "";
  });
})();
