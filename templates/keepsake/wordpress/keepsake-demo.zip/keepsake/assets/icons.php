<?php
/**
 * Keepsake's icons (original line icons by K&A Digital Studio), printed once per page.
 *
 * @package Keepsake
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">
  <symbol id="rings" viewBox="0 0 24 24"><circle cx="9" cy="14" r="5.5"/><circle cx="15" cy="14" r="5.5"/><path d="m13.2 5.5 1.8-2 1.8 2-1.8 1.8z"/></symbol>
  <symbol id="heart" viewBox="0 0 24 24"><path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.4 4.3 4.3 0 0 1 19.5 10c0 5.4-7.5 10-7.5 10z"/></symbol>
  <symbol id="sprig" viewBox="0 0 24 24"><path d="M6 20C9 14 13 9 19 4"/><path d="M9.6 14.6c-2.6.2-4.4-1-5.1-3.2 2.4-.4 4.3.6 5.1 3.2zM12.6 10.8c-.4-2.6.6-4.6 2.8-5.6.6 2.4-.3 4.5-2.8 5.6zM13 11.2c2.6-.6 4.6.2 5.6 2.3-2.4.7-4.5-.1-5.6-2.3zM9.9 14.3c2.6-.4 4.5.5 5.4 2.7-2.4.5-4.4-.5-5.4-2.7z"/></symbol>
  <symbol id="glasses" viewBox="0 0 24 24"><path d="M5.5 3.5h5l-.4 5a2.1 2.1 0 0 1-4.2 0z"/><path d="M13.5 3.5h5l-.4 5a2.1 2.1 0 0 1-4.2 0z"/><path d="M8 10.6v8.9M16 10.6v8.9M5.5 19.5h5M13.5 19.5h5"/><path d="M6 6h4M14 6h4"/></symbol>
  <symbol id="music" viewBox="0 0 24 24"><path d="M9 18V5.5l10-2V16"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/><path d="M9 9.5l10-2"/></symbol>
  <symbol id="camera" viewBox="0 0 24 24"><path d="M4 8a1.5 1.5 0 0 1 1.5-1.5h2.2L9.2 4.5h5.6l1.5 2h2.2A1.5 1.5 0 0 1 20 8v9.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 17.5z"/><circle cx="12" cy="12.5" r="3.5"/></symbol>
  <symbol id="hanger" viewBox="0 0 24 24"><path d="M10 6.5a2 2 0 1 1 2.7 1.9c-.4.1-.7.5-.7.9V10"/><path d="M12 10 3.6 16.2a1 1 0 0 0 .6 1.8h15.6a1 1 0 0 0 .6-1.8z"/></symbol>
  <symbol id="plate" viewBox="0 0 24 24"><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="3"/><path d="M3 4v4.5a1.5 1.5 0 0 0 3 0V4M4.5 9.5V20M21 4c-1.6 0-2.5 2-2.5 5s.8 3.5 2.5 3.5V20"/></symbol>
  <symbol id="gift" viewBox="0 0 24 24"><rect x="4" y="9" width="16" height="11" rx="1.5"/><path d="M3 9h18M12 9v11"/><path d="M12 9c-1.5-3-5-4-5.5-2S9 9 12 9zm0 0c1.5-3 5-4 5.5-2S15 9 12 9z"/></symbol>
  <symbol id="plane" viewBox="0 0 24 24"><path d="M10.5 13.5 4 11.5l1.5-1.5 7 .5 4.5-4.5a2 2 0 0 1 3 3L15.5 13.5l.5 7-1.5 1.5-2-6.5-3 3v2.5l-1.2 1.2-1.3-3.3-3.3-1.3L4.9 16.4h2.5z"/></symbol>
  <symbol id="car" viewBox="0 0 24 24"><path d="M4 16.5v-4l1.8-4.7A1.5 1.5 0 0 1 7.2 7h9.6a1.5 1.5 0 0 1 1.4.8L20 12.5v4"/><path d="M3.5 12.5h17v4.5h-17zM6 17v2M18 17v2"/><circle cx="7.5" cy="14.7" r=".6"/><circle cx="16.5" cy="14.7" r=".6"/></symbol>
  <symbol id="bus" viewBox="0 0 24 24"><rect x="5" y="3.5" width="14" height="14" rx="2.5"/><path d="M5 11h14M5 7h14M7.5 17.5v2.5M16.5 17.5v2.5"/><circle cx="8.5" cy="14.2" r=".6"/><circle cx="15.5" cy="14.2" r=".6"/></symbol>
  <symbol id="bed" viewBox="0 0 24 24"><path d="M3 19.5V6M3 15.5h18v4M21 15.5v-3a2.5 2.5 0 0 0-2.5-2.5H11v5.5"/><circle cx="7" cy="11.5" r="2"/></symbol>
  <symbol id="map" viewBox="0 0 24 24"><path d="m3.5 6.5 5.5-2 6 2 5.5-2v13l-5.5 2-6-2-5.5 2z"/><path d="M9 4.5v13M15 6.5v13"/></symbol>
  <symbol id="umbrella" viewBox="0 0 24 24"><path d="M3.5 12a8.5 8.5 0 0 1 17 0z"/><path d="M12 12v6.5a2 2 0 0 1-4 0M12 3.5v-1"/></symbol>
  <symbol id="users" viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.2"/><path d="M3.5 19.5a5.5 5.5 0 0 1 11 0"/><path d="M15.5 5.2a3 3 0 0 1 0 5.6M17.5 14.3a5.3 5.3 0 0 1 3 5.2"/></symbol>
  <symbol id="child" viewBox="0 0 24 24"><circle cx="12" cy="6" r="2.5"/><path d="M8 11.5l4-2 4 2M12 9.5v5M12 14.5l-2.5 5M12 14.5l2.5 5"/></symbol>
  <symbol id="access" viewBox="0 0 24 24"><circle cx="12" cy="4.5" r="1.8"/><path d="M5.5 8.5 12 9.5l6.5-1M12 9.5v5l-3 6M12 14.5l3 6"/></symbol>
  <symbol id="info" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.6v.4"/></symbol>
  <symbol id="mail" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></symbol>
  <symbol id="pin" viewBox="0 0 24 24"><path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/></symbol>
  <symbol id="calendar" viewBox="0 0 24 24"><rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 10h16"/></symbol>
  <symbol id="clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></symbol>
  <symbol id="check" viewBox="0 0 24 24"><path d="m5 12.5 4.5 4.5L19 7.5"/></symbol>
  <symbol id="arrow" viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></symbol>
  <symbol id="prev" viewBox="0 0 24 24"><path d="m15 5-7 7 7 7"/></symbol>
  <symbol id="next" viewBox="0 0 24 24"><path d="m9 5 7 7-7 7"/></symbol>
  <symbol id="close" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></symbol>
  <symbol id="plus" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></symbol>
  <symbol id="menu" viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></symbol>
  <symbol id="sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M4.6 4.6 6 6M18 18l1.4 1.4M2.5 12h2M19.5 12h2M4.6 19.4 6 18M18 6l1.4-1.4"/></symbol>
  <symbol id="moon" viewBox="0 0 24 24"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></symbol>
</svg>
